// Scrutiny Board Management System - web server
// Rajarata University of Sri Lanka - Faculty of Applied Sciences
const express = require('express');
const session = require('express-session');
const multer = require('multer');
const mysql = require('mysql2/promise');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

// ---------------------------------------------------------------- config
const CFG = {
  port: +process.env.PORT || 3000,
  db: {
    host: process.env.DB_HOST || 'localhost',
    port: +process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || '1234',
    database: process.env.DB_NAME || 'ScrutinyBoardDB',
  },
  secret: process.env.SESSION_SECRET || crypto.randomBytes(24).toString('hex'),
  maxFailed: 5,
};
const UPLOAD_DIR = path.join(__dirname, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const pool = mysql.createPool({
  ...CFG.db,
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true,
  charset: 'utf8mb4',
});

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(session({
  secret: CFG.secret,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', maxAge: 8 * 3600 * 1000 },
}));
app.use(express.static(path.join(__dirname, 'public')));

// ---------------------------------------------------------------- helpers
const q = async (sql, params = []) => (await pool.query(sql, params))[0];
const one = async (sql, params = []) => (await q(sql, params))[0] || null;
const val = async (sql, params = []) => {
  const r = await one(sql, params);
  return r ? Object.values(r)[0] : null;
};
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (m) => new HttpError(400, m);
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const sha = (salt, pw) => crypto.createHash('sha256').update(salt + pw).digest('hex');
const newSalt = () => crypto.randomBytes(8).toString('hex');
const tempPassword = () => 'Rusl@' + (1000 + crypto.randomInt(9000));
const strong = (p) => typeof p === 'string' && p.length >= 8 && /[A-Za-z]/.test(p) && /\d/.test(p);
const isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s));
const isTime = (s) => typeof s === 'string' && /^\d{2}:\d{2}(:\d{2})?$/.test(s);
const hhmm = (s) => (s.length === 5 ? s + ':00' : s);
const weekend = (d) => { const w = new Date(d + 'T00:00:00Z').getUTCDay(); return w === 0 || w === 6; };

const DOC_TYPES = ['Question Paper', 'Marking Scheme', 'Moderator Report'];
const STAGES = ['Paper setting', 'Submitted', 'Under moderation', 'Approved', 'Final printing'];

async function notify(userId, type, message) {
  await q('INSERT INTO NOTIFICATION (type, message, user_id) VALUES (?,?,?)', [type, message.slice(0, 255), userId]);
}
async function setStatus(paperId, status) {
  await q('UPDATE EXAM_PAPER SET status=? WHERE paper_id=?', [status, paperId]);
  await q('INSERT INTO PAPER_STATUS_HISTORY (status, paper_id) VALUES (?,?)', [status, paperId]);
}
async function docsPresent(paperId) {
  return +(await val(
    `SELECT COUNT(DISTINCT doc_type) FROM DOCUMENT WHERE paper_id=? AND doc_type IN (?,?,?)`,
    [paperId, ...DOC_TYPES]));
}

// Role / scope middleware
const auth = (req, res, next) => {
  if (!req.session.user || !req.session.user.role) return res.status(401).json({ error: 'Not logged in' });
  next();
};
const need = (...roles) => (req, res, next) => {
  if (!roles.includes(req.session.user.role)) return res.status(403).json({ error: 'Your role is not allowed to do this' });
  next();
};
const isAdmin = (u) => u.role === 'Administrator';
// SQL fragment limiting rows to the user's department (administrator sees all)
const scope = (u, col) => (u.dept && !isAdmin(u) ? { sql: ` AND ${col} = ?`, args: [u.dept] } : { sql: '', args: [] });

// Make sure the paper exists and belongs to the user's department
async function paperFor(u, id) {
  const p = await one(
    `SELECT p.*, sub.dept_id, sub.subject_name FROM EXAM_PAPER p JOIN SUBJECT sub ON sub.subject_id=p.subject_id
     WHERE p.paper_id=?`, [id]);
  if (!p) throw new HttpError(404, 'Paper not found');
  if (u.dept && !isAdmin(u) && p.dept_id !== u.dept) throw new HttpError(403, 'Paper belongs to another department');
  return p;
}
async function boardFor(u, id) {
  const b = await one('SELECT * FROM SCRUTINY_BOARD WHERE board_id=?', [id]);
  if (!b) throw new HttpError(404, 'Board not found');
  if (u.dept && !isAdmin(u) && b.dept_id !== u.dept) throw new HttpError(403, 'Board belongs to another department');
  return b;
}
async function meetingFor(u, id) {
  const m = await one('SELECT m.*, b.dept_id, b.board_name FROM BOARD_MEETING m JOIN SCRUTINY_BOARD b ON b.board_id=m.board_id WHERE m.meeting_id=?', [id]);
  if (!m) throw new HttpError(404, 'Meeting not found');
  if (u.dept && !isAdmin(u) && m.dept_id !== u.dept) throw new HttpError(403, 'Meeting belongs to another department');
  return m;
}

// ---------------------------------------------------------------- auth
app.post('/api/login', wrap(async (req, res) => {
  const { email, password } = req.body || {};
  const u = await one('SELECT * FROM USERS WHERE email=?', [String(email || '').trim()]);
  const fail = () => res.status(401).json({ error: 'Invalid email or password' });
  if (!u) return fail();
  if (u.failed_attempts >= CFG.maxFailed)
    return res.status(423).json({ error: 'Account locked after too many failed attempts. Ask the administrator to unlock it.' });
  if (!u.password_hash || sha(u.salt, String(password || '')) !== u.password_hash) {
    await q('UPDATE USERS SET failed_attempts=failed_attempts+1 WHERE user_id=?', [u.user_id]);
    const left = CFG.maxFailed - (u.failed_attempts + 1);
    return res.status(401).json({ error: left <= 0 ? 'Invalid email or password. The account is now locked.' : `Invalid email or password. ${left} attempt(s) left.` });
  }
  await q('UPDATE USERS SET failed_attempts=0 WHERE user_id=?', [u.user_id]);
  const roles = (await q(
    `SELECT r.role_name FROM USER_ROLE ur JOIN ROLE r ON r.role_id=ur.role_id
     WHERE ur.user_id=? AND ur.is_active=TRUE ORDER BY r.role_id`, [u.user_id])).map((r) => r.role_name);
  if (!roles.length) return res.status(403).json({ error: 'This account has no active role' });
  req.session.user = { id: u.user_id, name: u.name, email: u.email, dept: u.dept_id, roles, role: roles.length === 1 ? roles[0] : null, mustChange: !!u.must_change_password };
  res.json({ roles, mustChange: !!u.must_change_password, role: req.session.user.role });
}));

app.post('/api/select-role', wrap(async (req, res) => {
  const s = req.session.user;
  if (!s) return res.status(401).json({ error: 'Not logged in' });
  if (!req.body.role) { s.role = null; return res.json({ ok: true }); }   // "switch role": back to the role picker
  if (!s.roles.includes(req.body.role)) throw bad('Role not available for this account');
  s.role = req.body.role;
  res.json({ ok: true });
}));

app.post('/api/logout', (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.get('/api/me', wrap(async (req, res) => {
  const s = req.session.user;
  if (!s) return res.json({ user: null });
  const dept = s.dept ? await val('SELECT dept_name FROM DEPARTMENT WHERE dept_id=?', [s.dept]) : null;
  const unread = s.id ? +(await val('SELECT COUNT(*) FROM NOTIFICATION WHERE user_id=? AND read_at IS NULL', [s.id])) : 0;
  res.json({ user: { id: s.id, name: s.name, email: s.email, roles: s.roles, role: s.role, dept: s.dept, deptName: dept, mustChange: s.mustChange, unread } });
}));

app.post('/api/change-password', wrap(async (req, res) => {
  const s = req.session.user;
  if (!s) return res.status(401).json({ error: 'Not logged in' });
  const { current, password } = req.body || {};
  const u = await one('SELECT salt, password_hash FROM USERS WHERE user_id=?', [s.id]);
  if (!s.mustChange && sha(u.salt, String(current || '')) !== u.password_hash) throw bad('Current password is incorrect');
  if (!strong(password)) throw bad('Password must be 8+ characters with letters and digits');
  const salt = newSalt();
  await q('UPDATE USERS SET salt=?, password_hash=?, must_change_password=FALSE, failed_attempts=0 WHERE user_id=?', [salt, sha(salt, password), s.id]);
  s.mustChange = false;
  res.json({ ok: true });
}));

// everything below needs a logged-in user with a chosen role
app.use('/api', auth);
app.use('/api', (req, res, next) => {
  if (req.session.user.mustChange) return res.status(403).json({ error: 'Change your temporary password first', mustChange: true });
  next();
});

// ---------------------------------------------------------------- dashboard
app.get('/api/dashboard', wrap(async (req, res) => {
  const u = req.session.user;
  const sc = scope(u, 'sub.dept_id');
  const own = u.role === 'Lecturer' || u.role === 'Paper Setter';
  const ownSql = own ? ' AND p.prepared_by=?' : '';
  const ownArgs = own ? [u.id] : [];
  const base = `FROM EXAM_PAPER p JOIN SUBJECT sub ON sub.subject_id=p.subject_id WHERE 1=1${sc.sql}${ownSql}`;
  const args = [...sc.args, ...ownArgs];
  const byStage = await q(`SELECT p.status AS stage, COUNT(*) AS n ${base} GROUP BY p.status`, args);
  const total = +(await val(`SELECT COUNT(*) ${base}`, args));
  const late = +(await val(`SELECT COUNT(*) ${base} AND p.status='Paper setting' AND p.submission_deadline < CURDATE()`, args));
  const dueSoon = +(await val(`SELECT COUNT(*) ${base} AND p.status='Paper setting' AND p.submission_deadline BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)`, args));
  const atRisk = +(await val(
    `SELECT COUNT(*) FROM EXAM_PAPER p JOIN SUBJECT sub ON sub.subject_id=p.subject_id
     JOIN EXAM_TIMETABLE t ON t.paper_id=p.paper_id
     WHERE p.status NOT IN ('Approved','Final printing') AND t.exam_date >= CURDATE()
     AND DATEDIFF(t.exam_date, CURDATE()) <= 21${sc.sql}${ownSql}`, args));
  const sb = scope(u, 'b.dept_id');
  const upcoming = await q(
    `SELECT m.meeting_id, b.board_name, m.meeting_date, m.venue, m.mode FROM BOARD_MEETING m
     JOIN SCRUTINY_BOARD b ON b.board_id=m.board_id
     WHERE m.status='Scheduled' AND m.meeting_date >= CURDATE()${sb.sql} ORDER BY m.meeting_date LIMIT 5`, sb.args);
  const exams = await q(
    `SELECT p.title, t.exam_date, TIME_FORMAT(t.start_time,'%H:%i') AS start_time, t.venue, p.status
     FROM EXAM_TIMETABLE t JOIN EXAM_PAPER p ON p.paper_id=t.paper_id JOIN SUBJECT sub ON sub.subject_id=p.subject_id
     WHERE t.exam_date >= CURDATE()${sc.sql}${ownSql} ORDER BY t.exam_date LIMIT 5`, args);
  const unread = +(await val('SELECT COUNT(*) FROM NOTIFICATION WHERE user_id=? AND read_at IS NULL', [u.id]));
  res.json({ total, byStage, late, dueSoon, atRisk, upcoming, exams, unread });
}));

// ---------------------------------------------------------------- papers
const PAPER_SELECT = `
  SELECT p.paper_id, p.title, p.status, p.exam_date, p.submission_deadline, p.board_id, p.prepared_by,
         sub.subject_name, sub.semester, sub.dept_id, dep.dept_name, u.name AS lecturer,
         CASE WHEN p.status<>'Paper setting' THEN 'Completed'
              WHEN p.submission_deadline IS NULL THEN 'No deadline'
              WHEN p.submission_deadline < CURDATE() THEN 'Late'
              WHEN p.submission_deadline <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN 'Due soon'
              ELSE 'Pending' END AS submission,
         (SELECT COUNT(DISTINCT d.doc_type) FROM DOCUMENT d WHERE d.paper_id=p.paper_id AND d.doc_type IN ('Question Paper','Marking Scheme','Moderator Report')) AS docs_count,
         EXISTS(SELECT 1 FROM DOCUMENT d WHERE d.paper_id=p.paper_id AND d.doc_type='Question Paper') AS has_qp,
         EXISTS(SELECT 1 FROM DOCUMENT d WHERE d.paper_id=p.paper_id AND d.doc_type='Marking Scheme') AS has_ms,
         EXISTS(SELECT 1 FROM DOCUMENT d WHERE d.paper_id=p.paper_id AND d.doc_type='Moderator Report') AS has_mr
  FROM EXAM_PAPER p JOIN SUBJECT sub ON sub.subject_id=p.subject_id
  JOIN DEPARTMENT dep ON dep.dept_id=sub.dept_id LEFT JOIN USERS u ON u.user_id=p.prepared_by`;

app.get('/api/papers', wrap(async (req, res) => {
  const u = req.session.user;
  const sc = scope(u, 'sub.dept_id');
  let where = ` WHERE 1=1${sc.sql}`;
  const args = [...sc.args];
  if (u.role === 'Lecturer' || u.role === 'Paper Setter') { where += ' AND p.prepared_by=?'; args.push(u.id); }
  if (req.query.status) { where += ' AND p.status=?'; args.push(req.query.status); }
  res.json(await q(PAPER_SELECT + where + ' ORDER BY p.paper_id', args));
}));

app.get('/api/papers/:id', wrap(async (req, res) => {
  const u = req.session.user;
  const p = await paperFor(u, +req.params.id);
  const full = await one(PAPER_SELECT + ' WHERE p.paper_id=?', [p.paper_id]);
  const docs = await q(
    `SELECT d.doc_id, d.doc_type, d.submitted_date, us.name AS submitted_by,
            (SELECT JSON_ARRAYAGG(JSON_OBJECT('version_no', v.version_no, 'file_path', v.file_path, 'uploaded_at', DATE_FORMAT(v.uploaded_at,'%Y-%m-%d %H:%i')))
             FROM DOCUMENT_VERSION v WHERE v.doc_id=d.doc_id) AS versions
     FROM DOCUMENT d JOIN USERS us ON us.user_id=d.submitted_by WHERE d.paper_id=? ORDER BY d.doc_type`, [p.paper_id]);
  docs.forEach((d) => { if (typeof d.versions === 'string') d.versions = JSON.parse(d.versions); });
  const history = await q('SELECT status, change_date FROM PAPER_STATUS_HISTORY WHERE paper_id=? ORDER BY change_date, history_id', [p.paper_id]);
  const decisions = await q(
    `SELECT md.meeting_id, bm.meeting_date, md.decision FROM MEETING_DECISION md
     JOIN BOARD_MEETING bm ON bm.meeting_id=md.meeting_id WHERE md.paper_id=? ORDER BY bm.meeting_date`, [p.paper_id]);
  const approvals = await q(
    `SELECT h.decision, h.comments, h.approved_at, us.name AS hod FROM HOD_APPROVAL h JOIN USERS us ON us.user_id=h.hod_id
     WHERE h.paper_id=? ORDER BY h.approved_at`, [p.paper_id]);
  const slot = await one(
    `SELECT t.exam_date, TIME_FORMAT(t.start_time,'%H:%i') AS start_time, TIME_FORMAT(t.end_time,'%H:%i') AS end_time, t.venue,
            us.name AS invigilator FROM EXAM_TIMETABLE t LEFT JOIN USERS us ON us.user_id=t.invigilator_id WHERE t.paper_id=?`, [p.paper_id]);
  res.json({ paper: full, docs, history, decisions, approvals, slot });
}));

// create a subject + paper (HOD for own dept, admin anywhere)
app.post('/api/papers', need('Head of Department', 'Administrator'), wrap(async (req, res) => {
  const u = req.session.user;
  const b = req.body || {};
  const title = String(b.title || '').trim();
  if (!title) throw bad('Title is required');
  const sub = await one('SELECT * FROM SUBJECT WHERE subject_id=?', [b.subject_id]);
  if (!sub) throw bad('Choose a subject');
  if (u.dept && !isAdmin(u) && sub.dept_id !== u.dept) throw new HttpError(403, 'Subject belongs to another department');
  if (b.submission_deadline && !isDate(b.submission_deadline)) throw bad('Invalid deadline date');
  if (b.exam_date && !isDate(b.exam_date)) throw bad('Invalid exam date');
  if (b.board_id) { const bd = await boardFor(u, +b.board_id); if (bd.dept_id !== sub.dept_id) throw bad('Board belongs to another department'); }
  const [r] = await pool.query(
    `INSERT INTO EXAM_PAPER (title, exam_date, status, submission_deadline, subject_id, board_id, prepared_by) VALUES (?,?,?,?,?,?,?)`,
    [title, b.exam_date || null, 'Paper setting', b.submission_deadline || null, sub.subject_id, b.board_id || null, b.prepared_by || null]);
  await q('INSERT INTO PAPER_STATUS_HISTORY (status, paper_id) VALUES (?,?)', ['Paper setting', r.insertId]);
  if (b.prepared_by) await notify(+b.prepared_by, 'Reminder', `New paper assigned: ${title}.${b.submission_deadline ? ' Deadline: ' + b.submission_deadline : ''}`);
  res.json({ paper_id: r.insertId });
}));

// document upload (multipart, real file)
const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (req, file, cb) => cb(null, Date.now() + '-' + crypto.randomBytes(3).toString('hex') + '-' + file.originalname.replace(/[^\w.\-]+/g, '_')),
});
const upload = multer({
  storage,
  limits: { fileSize: 15 * 1024 * 1024 },
  fileFilter: (req, file, cb) => (/\.(pdf|docx?|xlsx?|pptx?|txt)$/i.test(file.originalname) ? cb(null, true) : cb(bad('Only PDF, Word, Excel, PowerPoint or text files are allowed'))),
});

app.post('/api/papers/:id/documents', need('Lecturer', 'Paper Setter', 'Moderator', 'Head of Department', 'Administrator'),
  upload.single('file'), wrap(async (req, res) => {
    const u = req.session.user;
    const cleanup = () => req.file && fs.unlink(req.file.path, () => {});
    try {
      const p = await paperFor(u, +req.params.id);
      const type = req.body.doc_type;
      if (!DOC_TYPES.includes(type)) throw bad('Choose a document type');
      if (!req.file) throw bad('Choose a file to upload');
      const ownerRole = u.role === 'Lecturer' || u.role === 'Paper Setter';
      if (ownerRole && p.prepared_by !== u.id) throw new HttpError(403, 'You can only upload documents for your own papers');
      if (ownerRole && type === 'Moderator Report') throw new HttpError(403, 'Only a moderator uploads the Moderator Report');
      if (u.role === 'Moderator' && type !== 'Moderator Report') throw new HttpError(403, 'Moderators upload the Moderator Report only');
      if (['Approved', 'Final printing'].includes(p.status)) throw bad('This paper is already approved; documents are locked');
      let doc = await one('SELECT doc_id FROM DOCUMENT WHERE paper_id=? AND doc_type=? ORDER BY doc_id DESC LIMIT 1', [p.paper_id, type]);
      if (!doc) {
        const [r] = await pool.query('INSERT INTO DOCUMENT (doc_type, submitted_date, submitted_by, paper_id) VALUES (?,CURDATE(),?,?)', [type, u.id, p.paper_id]);
        doc = { doc_id: r.insertId };
      }
      const ver = +(await val('SELECT COALESCE(MAX(version_no),0)+1 FROM DOCUMENT_VERSION WHERE doc_id=?', [doc.doc_id]));
      await q('INSERT INTO DOCUMENT_VERSION (version_no, file_path, doc_id) VALUES (?,?,?)', [ver, '/uploads/' + req.file.filename, doc.doc_id]);
      res.json({ version: ver, docs_count: await docsPresent(p.paper_id) });
    } catch (e) { cleanup(); throw e; }
  }));

// uploaded files are only served to logged-in users
app.get('/uploads/:name', (req, res) => {
  if (!req.session.user || !req.session.user.role) return res.status(401).send('Login required');
  const f = path.join(UPLOAD_DIR, path.basename(req.params.name));
  if (!fs.existsSync(f)) return res.status(404).send('Not found');
  res.sendFile(f);
});

app.post('/api/papers/:id/submit', need('Lecturer', 'Paper Setter'), wrap(async (req, res) => {
  const u = req.session.user;
  const p = await paperFor(u, +req.params.id);
  if (p.prepared_by !== u.id) throw new HttpError(403, 'You can only submit your own papers');
  if (p.status !== 'Paper setting') throw bad('Paper is not in the Paper setting stage');
  if ((await docsPresent(p.paper_id)) < 3) throw bad('All 3 mandatory documents (Question Paper, Marking Scheme, Moderator Report) are required before submission');
  await setStatus(p.paper_id, 'Submitted');
  const hods = await q(
    `SELECT ur.user_id FROM USER_ROLE ur JOIN USERS us ON us.user_id=ur.user_id
     WHERE ur.role_id=1 AND ur.is_active=TRUE AND us.dept_id=?`, [p.dept_id]);
  for (const h of hods) await notify(h.user_id, 'Approval', `"${p.title}" has been submitted and awaits scheduling for scrutiny.`);
  res.json({ ok: true });
}));

app.post('/api/papers/:id/approve', need('Head of Department'), wrap(async (req, res) => {
  const u = req.session.user;
  const p = await paperFor(u, +req.params.id);
  const { decision, comments } = req.body || {};
  if (!['Approved', 'Revision requested'].includes(decision)) throw bad('Invalid decision');
  if (p.status !== 'Under moderation') throw bad('Paper is not awaiting HOD approval');
  if (decision === 'Approved') {
    const d = await val('SELECT decision FROM MEETING_DECISION WHERE paper_id=? ORDER BY meeting_id DESC LIMIT 1', [p.paper_id]);
    if (d !== 'Accepted' && d !== 'Minor faults') throw bad(`Cannot approve: the board has not accepted this paper (decision: ${d || 'none'})`);
  } else if (!String(comments || '').trim()) throw bad('Add a comment explaining the revision');
  await q('INSERT INTO HOD_APPROVAL (decision, comments, paper_id, hod_id) VALUES (?,?,?,?)', [decision, comments || null, p.paper_id, u.id]);
  if (decision === 'Approved') {
    await setStatus(p.paper_id, 'Approved');
    if (p.prepared_by) await notify(p.prepared_by, 'Approved', `Your paper "${p.title}" has been approved.`);
  } else {
    await setStatus(p.paper_id, 'Paper setting');
    if (p.prepared_by) await notify(p.prepared_by, 'Revision', `Revision requested for "${p.title}": ${comments}`);
  }
  res.json({ ok: true });
}));

app.post('/api/papers/:id/print', need('Head of Department', 'Administrator'), wrap(async (req, res) => {
  const p = await paperFor(req.session.user, +req.params.id);
  if (p.status !== 'Approved') throw bad('Only approved papers can be sent to final printing');
  await setStatus(p.paper_id, 'Final printing');
  res.json({ ok: true });
}));

app.post('/api/remind', need('Head of Department', 'Administrator'), wrap(async (req, res) => {
  const u = req.session.user;
  const sc = scope(u, 'sub.dept_id');
  const rows = await q(
    `SELECT p.prepared_by, p.title, p.submission_deadline FROM EXAM_PAPER p JOIN SUBJECT sub ON sub.subject_id=p.subject_id
     WHERE p.status='Paper setting' AND p.prepared_by IS NOT NULL AND p.submission_deadline IS NOT NULL
     AND p.submission_deadline <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)${sc.sql}`, sc.args);
  for (const r of rows) await notify(r.prepared_by, 'Reminder', `Submit documents for "${r.title}" before ${r.submission_deadline}.`);
  res.json({ sent: rows.length });
}));

// ---------------------------------------------------------------- lookups
app.get('/api/lookups', wrap(async (req, res) => {
  const u = req.session.user;
  const sd = scope(u, 'dept_id');
  const sc = scope(u, 'us.dept_id');
  res.json({
    departments: await q('SELECT d.dept_id, d.dept_name FROM DEPARTMENT d ORDER BY dept_id'),
    roles: await q('SELECT role_id, role_name FROM ROLE ORDER BY role_id'),
    subjects: await q(`SELECT subject_id, subject_name, semester, dept_id FROM SUBJECT WHERE 1=1${sd.sql} ORDER BY subject_name`, sd.args),
    boards: await q(`SELECT board_id, board_name, dept_id FROM SCRUTINY_BOARD WHERE 1=1${sd.sql} ORDER BY board_id`, sd.args),
    staff: await q(`SELECT us.user_id, us.name, us.dept_id FROM USERS us WHERE 1=1${sc.sql} ORDER BY us.name`, sc.args),
    lecturers: await q(
      `SELECT DISTINCT us.user_id, us.name FROM USERS us JOIN USER_ROLE ur ON ur.user_id=us.user_id
       WHERE ur.role_id IN (2,6) AND ur.is_active=TRUE${sc.sql} ORDER BY us.name`, sc.args),
  });
}));

// ---------------------------------------------------------------- meetings
app.get('/api/meetings', wrap(async (req, res) => {
  const u = req.session.user;
  const sc = scope(u, 'b.dept_id');
  let extra = '', args = [...sc.args];
  if (u.role === 'Board Member') { extra = ' AND m.board_id IN (SELECT board_id FROM BOARD_MEMBER WHERE user_id=?)'; args.push(u.id); }
  res.json(await q(
    `SELECT m.meeting_id, m.meeting_date, m.venue, m.mode, m.quorum, m.status, b.board_name, b.board_id,
            (SELECT COUNT(*) FROM MEETING_DECISION md WHERE md.meeting_id=m.meeting_id) AS agenda_items,
            (SELECT COUNT(*) FROM MEMBER_ATTENDANCE a WHERE a.meeting_id=m.meeting_id AND a.present=TRUE) AS present
     FROM BOARD_MEETING m JOIN SCRUTINY_BOARD b ON b.board_id=m.board_id WHERE 1=1${sc.sql}${extra} ORDER BY m.meeting_date DESC`, args));
}));

app.get('/api/meetings/:id', wrap(async (req, res) => {
  const m = await meetingFor(req.session.user, +req.params.id);
  const agenda = await q(
    `SELECT p.paper_id, p.title, p.status, md.decision FROM MEETING_DECISION md JOIN EXAM_PAPER p ON p.paper_id=md.paper_id
     WHERE md.meeting_id=? ORDER BY p.paper_id`, [m.meeting_id]);
  const members = await q(
    `SELECT us.user_id, us.name, a.present, a.join_time,
            (SELECT is_available FROM LECTURER_AVAILABILITY la WHERE la.user_id=us.user_id AND la.available_date=?) AS available
     FROM BOARD_MEMBER bm JOIN USERS us ON us.user_id=bm.user_id
     LEFT JOIN MEMBER_ATTENDANCE a ON a.meeting_id=? AND a.user_id=bm.user_id WHERE bm.board_id=? ORDER BY us.name`,
    [m.meeting_date, m.meeting_id, m.board_id]);
  const eligible = await q(
    `SELECT p.paper_id, p.title, p.status FROM EXAM_PAPER p
     WHERE p.board_id=? AND p.status IN ('Submitted','Under moderation')
     AND p.paper_id NOT IN (SELECT paper_id FROM MEETING_DECISION WHERE meeting_id=?)`, [m.board_id, m.meeting_id]);
  res.json({ meeting: m, agenda, members, eligible });
}));

app.get('/api/suggest-dates', need('Head of Department', 'Administrator'), wrap(async (req, res) => {
  const b = await boardFor(req.session.user, +req.query.board_id);
  res.json(await q(
    `WITH RECURSIVE days(d, n) AS (SELECT CURDATE() + INTERVAL 1 DAY, 1 UNION ALL SELECT d + INTERVAL 1 DAY, n + 1 FROM days WHERE n < 30)
     SELECT d AS date, DAYNAME(d) AS day FROM days WHERE DAYOFWEEK(d) NOT IN (1,7)
     AND NOT EXISTS (SELECT 1 FROM BOARD_MEETING m WHERE m.board_id=? AND m.meeting_date=d AND m.status<>'Cancelled')
     AND NOT EXISTS (SELECT 1 FROM EXAM_TIMETABLE t JOIN EXAM_PAPER p ON p.paper_id=t.paper_id WHERE p.board_id=? AND t.exam_date=d)
     AND NOT EXISTS (SELECT 1 FROM BOARD_MEMBER bm JOIN LECTURER_AVAILABILITY la ON la.user_id=bm.user_id
                     WHERE bm.board_id=? AND la.available_date=d AND la.is_available=FALSE)
     ORDER BY d LIMIT 8`, [b.board_id, b.board_id, b.board_id]));
}));

app.post('/api/meetings', need('Head of Department', 'Administrator'), wrap(async (req, res) => {
  const u = req.session.user;
  const { board_id, meeting_date, venue, mode, quorum, force, papers } = req.body || {};
  const b = await boardFor(u, +board_id);
  if (!isDate(meeting_date)) throw bad('Enter a valid meeting date');
  if (!['Physical', 'Online'].includes(mode)) throw bad('Mode must be Physical or Online');
  const qn = +quorum || 2;
  const warnings = [];
  if (await val('SELECT meeting_date < CURDATE() FROM (SELECT ? AS meeting_date) x', [meeting_date])) throw bad('Meeting date cannot be in the past');
  if (await val("SELECT COUNT(*) FROM BOARD_MEETING WHERE board_id=? AND meeting_date=? AND status<>'Cancelled'", [b.board_id, meeting_date]))
    throw bad('This board already has a meeting on that date');
  if (weekend(meeting_date)) warnings.push('The date is a weekend.');
  const exams = await q(
    `SELECT p.title FROM EXAM_TIMETABLE t JOIN EXAM_PAPER p ON p.paper_id=t.paper_id WHERE p.board_id=? AND t.exam_date=?`, [b.board_id, meeting_date]);
  if (exams.length) warnings.push(`This board has exam(s) on that date: ${exams.map((e) => e.title).join(', ')}.`);
  const total = +(await val('SELECT COUNT(*) FROM BOARD_MEMBER WHERE board_id=?', [b.board_id]));
  const unavailable = await q(
    `SELECT us.name FROM BOARD_MEMBER bm JOIN USERS us ON us.user_id=bm.user_id
     JOIN LECTURER_AVAILABILITY la ON la.user_id=us.user_id WHERE bm.board_id=? AND la.available_date=? AND la.is_available=FALSE`, [b.board_id, meeting_date]);
  if (unavailable.length) warnings.push(`Unavailable members: ${unavailable.map((x) => x.name).join(', ')}.`);
  if (total - unavailable.length < qn) warnings.push(`Quorum of ${qn} cannot be met (${total - unavailable.length} of ${total} members available).`);
  if (warnings.length && !force) return res.status(409).json({ warnings });

  const [r] = await pool.query('INSERT INTO BOARD_MEETING (meeting_date, venue, mode, quorum, status, board_id) VALUES (?,?,?,?,?,?)',
    [meeting_date, venue || null, mode, qn, 'Scheduled', b.board_id]);
  const members = await q('SELECT user_id FROM BOARD_MEMBER WHERE board_id=?', [b.board_id]);
  for (const m of members) await notify(m.user_id, 'Meeting', `Scrutiny board meeting on ${meeting_date} at ${venue || 'TBA'} (${mode}).`);
  const rejected = await addAgenda(r.insertId, b.board_id, meeting_date, papers || []);
  res.json({ meeting_id: r.insertId, rejected });
}));

async function addAgenda(meetingId, boardId, meetingDate, ids) {
  const rejected = [];
  for (const pid of ids) {
    const p = await one('SELECT paper_id, title, status, board_id FROM EXAM_PAPER WHERE paper_id=?', [pid]);
    if (!p || p.board_id !== boardId) { rejected.push(`#${pid}: not part of this board`); continue; }
    if (!['Submitted', 'Under moderation'].includes(p.status)) { rejected.push(`${p.title}: not submitted yet`); continue; }
    if ((await docsPresent(p.paper_id)) < 3) { rejected.push(`${p.title}: mandatory documents missing`); continue; }
    if (await val('SELECT COUNT(*) FROM EXAM_TIMETABLE WHERE paper_id=? AND exam_date < ?', [p.paper_id, meetingDate])) { rejected.push(`${p.title}: exam is before the meeting date`); continue; }
    await q('INSERT IGNORE INTO MEETING_DECISION (meeting_id, paper_id, decision) VALUES (?,?,?)', [meetingId, p.paper_id, 'Pending']);
    if (p.status === 'Submitted') await setStatus(p.paper_id, 'Under moderation');
  }
  return rejected;
}

app.post('/api/meetings/:id/agenda', need('Head of Department', 'Administrator'), wrap(async (req, res) => {
  const m = await meetingFor(req.session.user, +req.params.id);
  if (m.status !== 'Scheduled') throw bad('Only scheduled meetings can change their agenda');
  const rejected = await addAgenda(m.meeting_id, m.board_id, m.meeting_date, (req.body.papers || []).map(Number));
  res.json({ rejected });
}));

app.post('/api/meetings/:id/decision', need('Moderator', 'Head of Department'), wrap(async (req, res) => {
  const u = req.session.user;
  const m = await meetingFor(u, +req.params.id);
  const { paper_id, decision } = req.body || {};
  if (!['Accepted', 'Minor faults', 'Major faults'].includes(decision)) throw bad('Invalid decision');
  const row = await one('SELECT decision FROM MEETING_DECISION WHERE meeting_id=? AND paper_id=?', [m.meeting_id, paper_id]);
  if (!row) throw bad('That paper is not on this meeting\'s agenda');
  const p = await paperFor(u, +paper_id);
  await q('UPDATE MEETING_DECISION SET decision=? WHERE meeting_id=? AND paper_id=?', [decision, m.meeting_id, p.paper_id]);
  if (decision === 'Major faults') {
    await setStatus(p.paper_id, 'Paper setting');
    if (p.prepared_by) await notify(p.prepared_by, 'Revision', `Major faults found in "${p.title}". Revise and resubmit; scrutiny will be repeated.`);
  } else if (p.prepared_by) {
    await notify(p.prepared_by, 'Moderation', `Decision for "${p.title}": ${decision}. Awaiting HOD approval.`);
  }
  res.json({ ok: true });
}));

app.post('/api/meetings/:id/attendance', need('Head of Department', 'Board Member', 'Moderator', 'Administrator'), wrap(async (req, res) => {
  const u = req.session.user;
  const m = await meetingFor(u, +req.params.id);
  const targetId = u.role === 'Board Member' ? u.id : +req.body.user_id;
  if (!(await val('SELECT COUNT(*) FROM BOARD_MEMBER WHERE board_id=? AND user_id=?', [m.board_id, targetId]))) throw bad('That user is not a member of this board');
  const present = !!req.body.present;
  await q('DELETE FROM MEMBER_ATTENDANCE WHERE meeting_id=? AND user_id=?', [m.meeting_id, targetId]);
  await q('INSERT INTO MEMBER_ATTENDANCE (present, join_time, meeting_id, user_id) VALUES (?,?,?,?)', [present, present ? new Date().toISOString().slice(0, 19).replace('T', ' ') : null, m.meeting_id, targetId]);
  const n = +(await val('SELECT COUNT(*) FROM MEMBER_ATTENDANCE WHERE meeting_id=? AND present=TRUE', [m.meeting_id]));
  res.json({ present: n, quorum: m.quorum, quorumMet: n >= m.quorum });
}));

app.post('/api/meetings/:id/status', need('Head of Department', 'Administrator'), wrap(async (req, res) => {
  const m = await meetingFor(req.session.user, +req.params.id);
  if (!['Completed', 'Cancelled'].includes(req.body.status)) throw bad('Invalid status');
  if (m.status !== 'Scheduled') throw bad('Meeting is already ' + m.status.toLowerCase());
  if (req.body.status === 'Completed') {
    const pending = +(await val("SELECT COUNT(*) FROM MEETING_DECISION WHERE meeting_id=? AND decision='Pending'", [m.meeting_id]));
    if (pending && !req.body.force) return res.status(409).json({ warnings: [`${pending} agenda item(s) still have no decision.`] });
  }
  await q('UPDATE BOARD_MEETING SET status=? WHERE meeting_id=?', [req.body.status, m.meeting_id]);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- timetable
app.get('/api/timetable', wrap(async (req, res) => {
  const u = req.session.user;
  const sc = scope(u, 'sub.dept_id');
  res.json(await q(
    `SELECT t.slot_id, t.paper_id, t.exam_date, DAYNAME(t.exam_date) AS day, TIME_FORMAT(t.start_time,'%H:%i') AS start_time,
            TIME_FORMAT(t.end_time,'%H:%i') AS end_time, t.venue, t.invigilator_id, us.name AS invigilator, p.title, p.status, sub.semester, dep.dept_name
     FROM EXAM_TIMETABLE t JOIN EXAM_PAPER p ON p.paper_id=t.paper_id JOIN SUBJECT sub ON sub.subject_id=p.subject_id
     JOIN DEPARTMENT dep ON dep.dept_id=sub.dept_id LEFT JOIN USERS us ON us.user_id=t.invigilator_id
     WHERE 1=1${sc.sql} ORDER BY t.exam_date, t.start_time`, sc.args));
}));

app.get('/api/readiness', wrap(async (req, res) => {
  const u = req.session.user;
  const sc = scope(u, 'sub.dept_id');
  res.json(await q(
    `SELECT p.paper_id, p.title, p.status, t.exam_date, DATEDIFF(t.exam_date, CURDATE()) AS days_left,
            CASE WHEN t.exam_date IS NULL THEN 'No timetable slot'
                 WHEN p.status IN ('Approved','Final printing') THEN 'Ready'
                 WHEN DATEDIFF(t.exam_date, CURDATE()) < 0 THEN 'Exam passed'
                 WHEN DATEDIFF(t.exam_date, CURDATE()) <= 21 THEN 'At risk' ELSE 'On track' END AS readiness
     FROM EXAM_PAPER p JOIN SUBJECT sub ON sub.subject_id=p.subject_id LEFT JOIN EXAM_TIMETABLE t ON t.paper_id=p.paper_id
     WHERE 1=1${sc.sql} ORDER BY t.exam_date IS NULL, t.exam_date`, sc.args));
}));

app.post('/api/timetable', need('Head of Department', 'Administrator'), wrap(async (req, res) => {
  const u = req.session.user;
  const b = req.body || {};
  const p = await paperFor(u, +b.paper_id);
  if (!isDate(b.exam_date) || !isTime(b.start_time) || !isTime(b.end_time)) throw bad('Enter a valid date and start/end times');
  const st = hhmm(b.start_time), en = hhmm(b.end_time);
  if (en <= st) throw bad('End time must be after start time');
  if (await val('SELECT ? < CURDATE()', [b.exam_date])) throw bad('The exam date cannot be in the past');
  const warnings = [];
  if (weekend(b.exam_date)) warnings.push('The exam date is a weekend.');
  const overlap = 'exam_date=? AND start_time<? AND end_time>? AND paper_id<>?';
  const oargs = [b.exam_date, en, st, p.paper_id];
  if (b.venue && (await val(`SELECT COUNT(*) FROM EXAM_TIMETABLE WHERE ${overlap} AND venue=?`, [...oargs, b.venue])))
    throw bad(`Clash: ${b.venue} is already booked at that time`);
  if (await val(
    `SELECT COUNT(*) FROM EXAM_TIMETABLE t JOIN EXAM_PAPER p2 ON p2.paper_id=t.paper_id JOIN SUBJECT s2 ON s2.subject_id=p2.subject_id
     WHERE t.exam_date=? AND t.start_time<? AND t.end_time>? AND t.paper_id<>? AND s2.dept_id=? AND s2.semester=?`, [...oargs, p.dept_id, p.semester]))
    throw bad('Clash: another paper for the same department and semester is scheduled at that time');
  if (b.invigilator_id) {
    if (await val(`SELECT COUNT(*) FROM EXAM_TIMETABLE WHERE ${overlap} AND invigilator_id=?`, [...oargs, b.invigilator_id])) throw bad('Clash: that invigilator is already assigned at that time');
    if (await val('SELECT COUNT(*) FROM LECTURER_AVAILABILITY WHERE user_id=? AND available_date=? AND is_available=FALSE', [b.invigilator_id, b.exam_date]))
      throw bad('That invigilator marked themselves unavailable on that date');
  }
  const days = +(await val('SELECT DATEDIFF(?, CURDATE())', [b.exam_date]));
  if (!['Approved', 'Final printing'].includes(p.status) && days <= 21)
    warnings.push(`Only ${days} day(s) until the exam and the paper is still "${p.status}".`);
  if (warnings.length && !b.force) return res.status(409).json({ warnings });
  await q(
    `INSERT INTO EXAM_TIMETABLE (paper_id, exam_date, start_time, end_time, venue, invigilator_id) VALUES (?,?,?,?,?,?)
     ON DUPLICATE KEY UPDATE exam_date=VALUES(exam_date), start_time=VALUES(start_time), end_time=VALUES(end_time), venue=VALUES(venue), invigilator_id=VALUES(invigilator_id)`,
    [p.paper_id, b.exam_date, st, en, b.venue || null, b.invigilator_id || null]);
  await q('UPDATE EXAM_PAPER SET exam_date=? WHERE paper_id=?', [b.exam_date, p.paper_id]);
  const msg = `Exam scheduled: ${p.title} on ${b.exam_date} ${b.start_time}-${b.end_time}${b.venue ? ' at ' + b.venue : ''}.`;
  if (p.prepared_by) await notify(p.prepared_by, 'Timetable', msg);
  if (b.invigilator_id) await notify(+b.invigilator_id, 'Timetable', 'You are the invigilator. ' + msg);
  res.json({ ok: true });
}));

app.delete('/api/timetable/:paperId', need('Head of Department', 'Administrator'), wrap(async (req, res) => {
  await paperFor(req.session.user, +req.params.paperId);
  await q('DELETE FROM EXAM_TIMETABLE WHERE paper_id=?', [+req.params.paperId]);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- availability & notifications
app.get('/api/availability', wrap(async (req, res) => {
  res.json(await q('SELECT available_date, is_available FROM LECTURER_AVAILABILITY WHERE user_id=? ORDER BY available_date', [req.session.user.id]));
}));
app.post('/api/availability', wrap(async (req, res) => {
  const { date, available } = req.body || {};
  if (!isDate(date)) throw bad('Enter a valid date');
  await q('INSERT INTO LECTURER_AVAILABILITY (user_id, available_date, is_available) VALUES (?,?,?) ON DUPLICATE KEY UPDATE is_available=VALUES(is_available)', [req.session.user.id, date, !!available]);
  res.json({ ok: true });
}));
app.delete('/api/availability/:date', wrap(async (req, res) => {
  await q('DELETE FROM LECTURER_AVAILABILITY WHERE user_id=? AND available_date=?', [req.session.user.id, req.params.date]);
  res.json({ ok: true });
}));

app.get('/api/notifications', wrap(async (req, res) => {
  res.json(await q('SELECT notification_id, type, message, sent_at, read_at FROM NOTIFICATION WHERE user_id=? ORDER BY sent_at DESC, notification_id DESC LIMIT 200', [req.session.user.id]));
}));
app.post('/api/notifications/read', wrap(async (req, res) => {
  await q('UPDATE NOTIFICATION SET read_at=NOW() WHERE user_id=? AND read_at IS NULL', [req.session.user.id]);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- reports (JSON or CSV)
const REPORTS = {
  stages: { title: 'Papers by workflow stage', sql: (sc) => [`SELECT p.status AS Stage, COUNT(*) AS Papers FROM EXAM_PAPER p JOIN SUBJECT sub ON sub.subject_id=p.subject_id WHERE 1=1${sc.sql} GROUP BY p.status`, sc.args] },
  validation: { title: 'Mandatory document validation', sql: (sc) => [`SELECT p.title AS Paper, IF(SUM(d.doc_type='Question Paper')>0,'Yes','MISSING') AS 'Question Paper', IF(SUM(d.doc_type='Marking Scheme')>0,'Yes','MISSING') AS 'Marking Scheme', IF(SUM(d.doc_type='Moderator Report')>0,'Yes','MISSING') AS 'Moderator Report', p.status AS Status FROM EXAM_PAPER p JOIN SUBJECT sub ON sub.subject_id=p.subject_id LEFT JOIN DOCUMENT d ON d.paper_id=p.paper_id WHERE 1=1${sc.sql} GROUP BY p.paper_id, p.title, p.status ORDER BY p.paper_id`, sc.args] },
  deadlines: { title: 'Submission deadlines', sql: (sc) => [`SELECT p.title AS Paper, us.name AS Lecturer, p.submission_deadline AS Deadline, CASE WHEN p.status<>'Paper setting' THEN 'Completed' WHEN p.submission_deadline < CURDATE() THEN 'Late' WHEN p.submission_deadline <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN 'Due soon' ELSE 'Pending' END AS Submission FROM EXAM_PAPER p JOIN SUBJECT sub ON sub.subject_id=p.subject_id LEFT JOIN USERS us ON us.user_id=p.prepared_by WHERE 1=1${sc.sql} ORDER BY p.submission_deadline`, sc.args] },
  decisions: { title: 'Board decisions', sql: (sc) => [`SELECT bm.meeting_date AS Meeting, p.title AS Paper, md.decision AS Decision FROM MEETING_DECISION md JOIN BOARD_MEETING bm ON bm.meeting_id=md.meeting_id JOIN EXAM_PAPER p ON p.paper_id=md.paper_id JOIN SUBJECT sub ON sub.subject_id=p.subject_id WHERE 1=1${sc.sql} ORDER BY bm.meeting_date`, sc.args] },
  attendance: { title: 'Meeting attendance & quorum', sql: (sc) => [`SELECT m.meeting_date AS Date, b.board_name AS Board, COALESCE(SUM(a.present=TRUE),0) AS Present, m.quorum AS Quorum, IF(COALESCE(SUM(a.present=TRUE),0)>=m.quorum,'Met','Not met') AS Quorum_status, m.status AS Status FROM BOARD_MEETING m JOIN SCRUTINY_BOARD b ON b.board_id=m.board_id LEFT JOIN MEMBER_ATTENDANCE a ON a.meeting_id=m.meeting_id WHERE 1=1${sc.sql.replace('sub.dept_id', 'b.dept_id')} GROUP BY m.meeting_id, m.meeting_date, b.board_name, m.quorum, m.status ORDER BY m.meeting_date`, sc.args] },
  approvals: { title: 'HOD approvals', sql: (sc) => [`SELECT p.title AS Paper, us.name AS HOD, h.decision AS Decision, h.comments AS Comments, h.approved_at AS Date FROM HOD_APPROVAL h JOIN EXAM_PAPER p ON p.paper_id=h.paper_id JOIN SUBJECT sub ON sub.subject_id=p.subject_id JOIN USERS us ON us.user_id=h.hod_id WHERE 1=1${sc.sql} ORDER BY h.approved_at`, sc.args] },
  readiness: { title: 'Exam readiness', sql: (sc) => [`SELECT p.title AS Paper, t.exam_date AS Exam_date, p.status AS Status, CASE WHEN t.exam_date IS NULL THEN 'No timetable slot' WHEN p.status IN ('Approved','Final printing') THEN 'Ready' WHEN DATEDIFF(t.exam_date, CURDATE()) < 0 THEN 'Exam passed' WHEN DATEDIFF(t.exam_date, CURDATE()) <= 21 THEN 'At risk' ELSE 'On track' END AS Readiness FROM EXAM_PAPER p JOIN SUBJECT sub ON sub.subject_id=p.subject_id LEFT JOIN EXAM_TIMETABLE t ON t.paper_id=p.paper_id WHERE 1=1${sc.sql} ORDER BY t.exam_date IS NULL, t.exam_date`, sc.args] },
};
const csvCell = (v) => { const s = v === null || v === undefined ? '' : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };

app.get('/api/reports', need('Head of Department', 'Administrator', 'Moderator'), (req, res) =>
  res.json(Object.entries(REPORTS).map(([key, r]) => ({ key, title: r.title }))));

app.get('/api/reports/:name', need('Head of Department', 'Administrator', 'Moderator'), wrap(async (req, res) => {
  const r = REPORTS[req.params.name];
  if (!r) throw new HttpError(404, 'Unknown report');
  const u = req.session.user;
  const sc = scope(u, 'sub.dept_id');
  const [sql, args] = r.sql(sc);
  const rows = await q(sql, args);
  if (req.query.format === 'csv') {
    const cols = rows.length ? Object.keys(rows[0]) : [];
    const body = [cols.map(csvCell).join(','), ...rows.map((x) => cols.map((c) => csvCell(x[c])).join(','))].join('\r\n');
    res.set('Content-Type', 'text/csv; charset=utf-8');
    res.set('Content-Disposition', `attachment; filename="${req.params.name}-report.csv"`);
    return res.send('﻿' + body);
  }
  res.json({ title: r.title, rows });
}));

// ---------------------------------------------------------------- administration
app.get('/api/admin/users', need('Administrator'), wrap(async (req, res) => {
  res.json(await q(
    `SELECT us.user_id, us.name, us.email, us.phone, us.dept_id, d.dept_name, us.failed_attempts, us.must_change_password,
            (SELECT GROUP_CONCAT(CONCAT(r.role_name, IF(ur.is_active,'','*')) ORDER BY r.role_id SEPARATOR ', ')
             FROM USER_ROLE ur JOIN ROLE r ON r.role_id=ur.role_id WHERE ur.user_id=us.user_id) AS roles
     FROM USERS us LEFT JOIN DEPARTMENT d ON d.dept_id=us.dept_id ORDER BY us.user_id`));
}));

app.post('/api/admin/users', need('Administrator'), wrap(async (req, res) => {
  const { name, email, phone, dept_id, role_id } = req.body || {};
  if (!String(name || '').trim() || !/^\S+@\S+\.\S+$/.test(String(email || ''))) throw bad('Name and a valid email are required');
  if (await val('SELECT COUNT(*) FROM USERS WHERE email=?', [email])) throw bad('That email is already registered');
  const tmp = tempPassword(), salt = newSalt();
  const [r] = await pool.query('INSERT INTO USERS (name, email, phone, dept_id, salt, password_hash, must_change_password) VALUES (?,?,?,?,?,?,TRUE)',
    [name.trim(), email.trim(), phone || null, dept_id || null, salt, sha(salt, tmp)]);
  if (role_id) await q('INSERT INTO USER_ROLE (user_id, role_id, assigned_date, is_active) VALUES (?,?,CURDATE(),TRUE)', [r.insertId, role_id]);
  res.json({ user_id: r.insertId, temporary_password: tmp });
}));

app.post('/api/admin/users/:id/reset-password', need('Administrator'), wrap(async (req, res) => {
  const tmp = tempPassword(), salt = newSalt();
  const [r] = await pool.query('UPDATE USERS SET salt=?, password_hash=?, must_change_password=TRUE, failed_attempts=0 WHERE user_id=?', [salt, sha(salt, tmp), +req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'User not found');
  res.json({ temporary_password: tmp });
}));

app.post('/api/admin/users/:id/roles', need('Administrator'), wrap(async (req, res) => {
  const { role_id, active } = req.body || {};
  if (!(await val('SELECT COUNT(*) FROM ROLE WHERE role_id=?', [role_id]))) throw bad('Unknown role');
  await q(`INSERT INTO USER_ROLE (user_id, role_id, assigned_date, is_active) VALUES (?,?,CURDATE(),?)
           ON DUPLICATE KEY UPDATE is_active=VALUES(is_active), assigned_date=CURDATE()`, [+req.params.id, role_id, active !== false]);
  res.json({ ok: true });
}));

app.get('/api/admin/structure', need('Administrator'), wrap(async (req, res) => {
  res.json({
    faculty: await q('SELECT * FROM FACULTY'),
    departments: await q('SELECT d.dept_id, d.dept_name FROM DEPARTMENT d ORDER BY dept_id'),
    subjects: await q('SELECT s.subject_id, s.subject_name, s.credits, s.semester, d.dept_name FROM SUBJECT s JOIN DEPARTMENT d ON d.dept_id=s.dept_id ORDER BY s.dept_id, s.semester, s.subject_name'),
    boards: await q('SELECT b.board_id, b.board_name, b.status, d.dept_name, (SELECT COUNT(*) FROM BOARD_MEMBER bm WHERE bm.board_id=b.board_id) AS members FROM SCRUTINY_BOARD b JOIN DEPARTMENT d ON d.dept_id=b.dept_id ORDER BY b.board_id'),
  });
}));
app.post('/api/admin/departments', need('Administrator'), wrap(async (req, res) => {
  const name = String(req.body.name || '').trim();
  if (!name) throw bad('Name is required');
  const fid = await val('SELECT MIN(faculty_id) FROM FACULTY');
  const [r] = await pool.query('INSERT INTO DEPARTMENT (dept_name, faculty_id) VALUES (?,?)', [name, fid]);
  res.json({ dept_id: r.insertId });
}));
app.post('/api/admin/subjects', need('Administrator'), wrap(async (req, res) => {
  const { subject_name, credits, semester, dept_id } = req.body || {};
  if (!String(subject_name || '').trim() || !dept_id || !(+credits > 0)) throw bad('Subject name, credits and department are required');
  const [r] = await pool.query('INSERT INTO SUBJECT (subject_name, credits, semester, dept_id) VALUES (?,?,?,?)', [subject_name.trim(), +credits, +semester || 1, dept_id]);
  res.json({ subject_id: r.insertId });
}));
app.post('/api/admin/boards', need('Administrator'), wrap(async (req, res) => {
  const { board_name, dept_id } = req.body || {};
  if (!String(board_name || '').trim() || !dept_id) throw bad('Board name and department are required');
  const [r] = await pool.query('INSERT INTO SCRUTINY_BOARD (board_name, dept_id) VALUES (?,?)', [board_name.trim(), dept_id]);
  res.json({ board_id: r.insertId });
}));
app.get('/api/admin/boards/:id/members', need('Administrator', 'Head of Department'), wrap(async (req, res) => {
  await boardFor(req.session.user, +req.params.id);
  res.json(await q('SELECT us.user_id, us.name, us.email FROM BOARD_MEMBER bm JOIN USERS us ON us.user_id=bm.user_id WHERE bm.board_id=? ORDER BY us.name', [+req.params.id]));
}));
app.post('/api/admin/boards/:id/members', need('Administrator', 'Head of Department'), wrap(async (req, res) => {
  await boardFor(req.session.user, +req.params.id);
  await q('INSERT IGNORE INTO BOARD_MEMBER (user_id, board_id) VALUES (?,?)', [req.body.user_id, +req.params.id]);
  res.json({ ok: true });
}));
app.delete('/api/admin/boards/:id/members/:uid', need('Administrator', 'Head of Department'), wrap(async (req, res) => {
  await boardFor(req.session.user, +req.params.id);
  await q('DELETE FROM BOARD_MEMBER WHERE board_id=? AND user_id=?', [+req.params.id, +req.params.uid]);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- errors
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'File is larger than 15 MB' : err.message });
  const status = err.status || 500;
  if (status === 500) console.error(err);
  if (err.code === 'ER_DUP_ENTRY') return res.status(400).json({ error: 'That record already exists' });
  res.status(status).json({ error: status === 500 ? 'Server error: ' + (err.sqlMessage || err.message) : err.message });
});

app.listen(CFG.port, () => console.log(`Scrutiny Board System running at http://localhost:${CFG.port}`));
