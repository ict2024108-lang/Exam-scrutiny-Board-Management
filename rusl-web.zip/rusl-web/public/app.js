'use strict';
// Scrutiny Board Management System - browser UI (no framework)

const $ = (s, r = document) => r.querySelector(s);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const state = { user: null, lookups: null, view: null };

// ------------------------------------------------------------------ api
async function api(path, opts = {}) {
  const o = { method: opts.method || 'GET', headers: {}, credentials: 'same-origin' };
  if (opts.form) o.body = opts.form;
  else if (opts.body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opts.body); }
  const res = await fetch(path, o);
  const ct = res.headers.get('content-type') || '';
  const data = ct.includes('json') ? await res.json() : null;
  if (!res.ok) {
    const err = new Error((data && data.error) || 'Request failed');
    err.status = res.status; err.data = data;
    if (res.status === 401 && state.user) { state.user = null; showAuth(); }
    throw err;
  }
  return data;
}
// POST that asks for confirmation when the server returns warnings (HTTP 409), then retries with force
async function postWithWarnings(path, body, method = 'POST') {
  try { return await api(path, { method, body }); }
  catch (e) {
    if (e.status === 409 && e.data && e.data.warnings) {
      if (!confirm('Please confirm:\n\n- ' + e.data.warnings.join('\n- ') + '\n\nContinue anyway?')) return null;
      return api(path, { method, body: { ...body, force: true } });
    }
    throw e;
  }
}
function toast(msg, isErr) {
  const t = $('#toast');
  t.textContent = msg; t.className = 'toast show' + (isErr ? ' err' : '');
  clearTimeout(toast.t); toast.t = setTimeout(() => (t.className = 'toast'), 3500);
}
const fail = (e) => toast(e.message, true);

// ------------------------------------------------------------------ small ui helpers
const BADGE = {
  'Paper setting': 'neutral', 'Submitted': 'info', 'Under moderation': 'warn', 'Approved': 'ok', 'Final printing': 'ok',
  'Late': 'bad', 'Due soon': 'warn', 'Pending': 'neutral', 'Completed': 'ok', 'No deadline': 'neutral',
  'Accepted': 'ok', 'Minor faults': 'warn', 'Major faults': 'bad', 'Revision requested': 'bad',
  'Scheduled': 'info', 'Cancelled': 'bad', 'Ready': 'ok', 'At risk': 'bad', 'On track': 'info', 'No timetable slot': 'warn', 'Exam passed': 'neutral',
};
const badge = (t) => `<span class="badge ${BADGE[t] || ''}">${esc(t)}</span>`;
const docIcons = (p) => `<span class="docs" title="Question Paper / Marking Scheme / Moderator Report">
  <span class="doc ${p.has_qp ? 'have' : ''}">Q</span><span class="doc ${p.has_ms ? 'have' : ''}">M</span><span class="doc ${p.has_mr ? 'have' : ''}">R</span></span>`;
const fmtDate = (d) => (d ? esc(String(d).slice(0, 10)) : '-');

function table(cols, rows, { onRow, empty = 'Nothing to show yet.' } = {}) {
  if (!rows.length) return `<div class="table-wrap"><div class="empty">${esc(empty)}</div></div>`;
  const head = cols.map((c) => `<th>${esc(c.h)}</th>`).join('');
  const body = rows.map((r, i) => `<tr class="${onRow ? 'click' : ''}" data-i="${i}">${cols.map((c) => `<td>${c.f(r)}</td>`).join('')}</tr>`).join('');
  return `<div class="table-wrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}
function bindRows(root, rows, fn) { root.querySelectorAll('tbody tr.click').forEach((tr) => tr.addEventListener('click', () => fn(rows[+tr.dataset.i]))); }

function modal(title, bodyHtml, { wide = false } = {}) {
  closeModal();
  const root = $('#modalRoot');
  root.innerHTML = `<div class="overlay" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal ${wide ? 'wide' : ''}">
    <div class="modal-head"><h3 style="margin:0;font-size:17px">${esc(title)}</h3><button class="icon-btn" data-close aria-label="Close">&times;</button></div>
    <div class="modal-body">${bodyHtml}</div></div></div>`;
  const ov = $('.overlay', root);
  ov.addEventListener('mousedown', (e) => { if (e.target === ov) closeModal(); });
  $('[data-close]', root).addEventListener('click', closeModal);
  return $('.modal-body', root);
}
function closeModal() { $('#modalRoot').innerHTML = ''; }
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

function opts(list, valueKey, labelKey, selected, blank) {
  return (blank !== undefined ? `<option value="">${esc(blank)}</option>` : '') +
    list.map((o) => `<option value="${esc(o[valueKey])}" ${String(o[valueKey]) === String(selected) ? 'selected' : ''}>${esc(o[labelKey])}</option>`).join('');
}
async function lookups(force) {
  if (!state.lookups || force) state.lookups = await api('/api/lookups');
  return state.lookups;
}
const role = () => state.user.role;
const isHod = () => role() === 'Head of Department';
const isAdmin = () => role() === 'Administrator';
const isSetter = () => role() === 'Lecturer' || role() === 'Paper Setter';

// ------------------------------------------------------------------ navigation
const NAV = {
  'Head of Department': ['dashboard', 'papers', 'meetings', 'timetable', 'readiness', 'boards', 'reports', 'availability', 'notifications', 'account'],
  'Lecturer': ['dashboard', 'papers', 'timetable', 'availability', 'notifications', 'account'],
  'Paper Setter': ['dashboard', 'papers', 'timetable', 'availability', 'notifications', 'account'],
  'Moderator': ['dashboard', 'papers', 'meetings', 'timetable', 'reports', 'availability', 'notifications', 'account'],
  'Board Member': ['dashboard', 'meetings', 'timetable', 'availability', 'notifications', 'account'],
  'Administrator': ['dashboard', 'papers', 'meetings', 'timetable', 'readiness', 'boards', 'users', 'structure', 'reports', 'notifications', 'account'],
};
const TITLES = {
  dashboard: 'Dashboard', papers: 'Exam Papers', meetings: 'Scrutiny Board Meetings', timetable: 'Examination Timetable', readiness: 'Exam Readiness',
  boards: 'Boards & Members', reports: 'Reports', availability: 'My Availability', notifications: 'Notifications', account: 'Account',
  users: 'Users & Roles', structure: 'Faculty Structure',
};
const VIEWS = {};

function buildNav() {
  const items = NAV[role()] || NAV.Lecturer;
  $('#nav').innerHTML = items.map((k) => `<button data-v="${k}">${esc(k === 'papers' && isSetter() ? 'My Papers' : TITLES[k])}${k === 'notifications' ? ` <span id="navCount" class="pill hidden"></span>` : ''}</button>`).join('');
  $('#nav').querySelectorAll('button').forEach((b) => b.addEventListener('click', () => { go(b.dataset.v); $('#sidebar').classList.remove('open'); }));
}
async function go(v) {
  state.view = v;
  $('#nav').querySelectorAll('button').forEach((b) => (b.dataset.v === v ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current')));
  $('#pageTitle').textContent = v === 'papers' && isSetter() ? 'My Papers' : TITLES[v];
  const view = $('#view');
  view.innerHTML = '<p class="muted">Loading...</p>';
  try { await VIEWS[v](view); } catch (e) { view.innerHTML = `<div class="errbox">${esc(e.message)}</div>`; }
  refreshBell();
}
async function refreshBell() {
  try {
    const { user } = await api('/api/me');
    if (!user) return;
    const n = user.unread;
    for (const id of ['bellCount', 'navCount']) { const el = $('#' + id); if (el) { el.textContent = n; el.classList.toggle('hidden', !n); } }
  } catch { /* ignore */ }
}

// ------------------------------------------------------------------ dashboard
VIEWS.dashboard = async (el) => {
  const d = await api('/api/dashboard');
  const stages = ['Paper setting', 'Submitted', 'Under moderation', 'Approved', 'Final printing'];
  const counts = Object.fromEntries(d.byStage.map((s) => [s.stage, s.n]));
  const max = Math.max(1, ...Object.values(counts));
  el.innerHTML = `
    <div class="grid cols-4" style="margin-bottom:16px">
      <div class="card stat"><div class="n">${d.total}</div><div class="l">Papers</div></div>
      <div class="card stat ${d.late ? 'bad' : 'ok'}"><div class="n">${d.late}</div><div class="l">Late submissions</div></div>
      <div class="card stat ${d.dueSoon ? 'warn' : ''}"><div class="n">${d.dueSoon}</div><div class="l">Due within 7 days</div></div>
      <div class="card stat ${d.atRisk ? 'bad' : 'ok'}"><div class="n">${d.atRisk}</div><div class="l">Exams at risk (&le; 21 days)</div></div>
    </div>
    <div class="grid cols-2">
      <div class="card"><h3>Papers by workflow stage</h3><div class="bars">
        ${stages.map((s) => `<div class="bar"><span>${esc(s)}</span><span class="track"><span class="fill" style="display:block;width:${((counts[s] || 0) / max) * 100}%"></span></span><b>${counts[s] || 0}</b></div>`).join('')}
      </div></div>
      <div class="card"><h3>Upcoming board meetings</h3>
        ${d.upcoming.length ? `<ul class="list">${d.upcoming.map((m) => `<li><span><b>${esc(m.board_name)}</b><br><span class="muted">${esc(m.venue || '')} (${esc(m.mode)})</span></span><span>${fmtDate(m.meeting_date)}</span></li>`).join('')}</ul>` : '<p class="muted">No meetings scheduled.</p>'}
      </div>
      <div class="card"><h3>Next examinations</h3>
        ${d.exams.length ? `<ul class="list">${d.exams.map((x) => `<li><span><b>${esc(x.title)}</b><br><span class="muted">${esc(x.venue || '')} ${esc(x.start_time)}</span></span><span style="text-align:right">${fmtDate(x.exam_date)}<br>${badge(x.status)}</span></li>`).join('')}</ul>` : '<p class="muted">No exams on the timetable.</p>'}
      </div>
      <div class="card"><h3>Your alerts</h3><p>${d.unread ? `You have <b>${d.unread}</b> unread notification(s).` : 'No unread notifications.'}</p>
        <button class="btn" id="dashNotif">Open notifications</button></div>
    </div>`;
  $('#dashNotif', el).addEventListener('click', () => go('notifications'));
};

// ------------------------------------------------------------------ papers
VIEWS.papers = async (el) => {
  const filter = VIEWS.papers.filter || '';
  const papers = await api('/api/papers' + (filter ? '?status=' + encodeURIComponent(filter) : ''));
  const stages = ['', 'Paper setting', 'Submitted', 'Under moderation', 'Approved', 'Final printing'];
  el.innerHTML = `
    <div class="toolbar">
      <div class="tabs" id="stageTabs">${stages.map((s) => `<button class="tab" aria-pressed="${s === filter}" data-s="${esc(s)}">${s || 'All'}</button>`).join('')}</div>
      <span class="grow"></span>
      ${isHod() || isAdmin() ? '<button class="btn" id="remindBtn">Send deadline reminders</button><button class="btn primary" id="newPaper">New paper</button>' : ''}
    </div>
    <div id="paperTable"></div>`;
  $('#paperTable', el).innerHTML = table([
    { h: 'Paper', f: (p) => `<b>${esc(p.title)}</b><br><span class="muted">${esc(p.dept_name)} &middot; Sem ${esc(p.semester)}</span>` },
    { h: 'Setter', f: (p) => esc(p.lecturer || '-') },
    { h: 'Stage', f: (p) => badge(p.status) },
    { h: 'Documents', f: (p) => `${docIcons(p)} <span class="muted">${p.docs_count}/3</span>` },
    { h: 'Deadline', f: (p) => `${fmtDate(p.submission_deadline)}<br>${badge(p.submission)}` },
    { h: 'Exam', f: (p) => fmtDate(p.exam_date) },
  ], papers, { onRow: true, empty: 'No papers found.' });
  bindRows(el, papers, (p) => openPaper(p.paper_id));
  el.querySelectorAll('#stageTabs .tab').forEach((b) => b.addEventListener('click', () => { VIEWS.papers.filter = b.dataset.s; go('papers'); }));
  const rb = $('#remindBtn', el);
  if (rb) rb.addEventListener('click', async () => { try { const r = await api('/api/remind', { method: 'POST', body: {} }); toast(`${r.sent} reminder(s) sent`); } catch (e) { fail(e); } });
  const nb = $('#newPaper', el);
  if (nb) nb.addEventListener('click', newPaperForm);
};

async function newPaperForm() {
  const L = await lookups(true);
  const body = modal('New exam paper', `
    <form id="npForm" class="stack">
      <label>Title<input name="title" required placeholder="e.g. Data Structures Final Paper"></label>
      <div class="row">
        <label>Subject<select name="subject_id" required>${opts(L.subjects, 'subject_id', 'subject_name', '', 'Choose...')}</select></label>
        <label>Scrutiny board<select name="board_id">${opts(L.boards, 'board_id', 'board_name', '', 'None')}</select></label>
      </div>
      <div class="row">
        <label>Paper setter<select name="prepared_by">${opts(L.lecturers, 'user_id', 'name', '', 'Unassigned')}</select></label>
        <label>Submission deadline<input type="date" name="submission_deadline"></label>
      </div>
      <p id="npErr" class="error"></p>
      <div class="actions"><button class="btn primary" type="submit">Create paper</button></div>
    </form>`);
  $('#npForm', body).addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    try { await api('/api/papers', { method: 'POST', body: f }); closeModal(); toast('Paper created'); go('papers'); }
    catch (er) { $('#npErr').textContent = er.message; }
  });
}

async function openPaper(id) {
  const d = await api('/api/papers/' + id).catch((e) => { fail(e); return null; });
  if (!d) return;
  const { paper: p, docs, history, decisions, approvals, slot } = d;
  const mine = isSetter() && p.prepared_by === state.user.id;
  const locked = ['Approved', 'Final printing'].includes(p.status);
  const canUpload = !locked && ((mine) || role() === 'Moderator' || isHod() || isAdmin());
  const types = isSetter() ? ['Question Paper', 'Marking Scheme'] : role() === 'Moderator' ? ['Moderator Report'] : ['Question Paper', 'Marking Scheme', 'Moderator Report'];
  const body = modal(p.title, `
    <dl class="kv">
      <dt>Subject</dt><dd>${esc(p.subject_name)} (${esc(p.dept_name)}, semester ${esc(p.semester)})</dd>
      <dt>Paper setter</dt><dd>${esc(p.lecturer || 'Unassigned')}</dd>
      <dt>Stage</dt><dd>${badge(p.status)}</dd>
      <dt>Submission deadline</dt><dd>${fmtDate(p.submission_deadline)} ${badge(p.submission)}</dd>
      <dt>Exam</dt><dd>${slot ? `${fmtDate(slot.exam_date)} ${esc(slot.start_time)}-${esc(slot.end_time)}, ${esc(slot.venue || 'venue TBA')}${slot.invigilator ? ', invigilator ' + esc(slot.invigilator) : ''}` : 'Not on the timetable yet'}</dd>
    </dl>
    <div><h3>Mandatory documents (${p.docs_count}/3)</h3>
      ${['Question Paper', 'Marking Scheme', 'Moderator Report'].map((t) => {
        const doc = docs.find((x) => x.doc_type === t);
        if (!doc) return `<p style="margin:4px 0"><span class="badge bad">Missing</span> ${t}</p>`;
        const vs = (doc.versions || []).slice().sort((a, b) => b.version_no - a.version_no);
        return `<p style="margin:4px 0"><span class="badge ok">Submitted</span> ${t} &mdash; ${vs.map((v) => `<a href="${esc(v.file_path)}" target="_blank" rel="noopener">v${v.version_no}</a> <span class="muted">(${esc(v.uploaded_at)})</span>`).join(', ')}</p>`;
      }).join('')}
      ${canUpload ? `<form id="upForm" class="row" style="margin-top:12px;align-items:end">
        <label>Document type<select name="doc_type">${types.map((t) => `<option>${t}</option>`).join('')}</select></label>
        <label>File (PDF, Word, ...)<input type="file" name="file" required></label>
        <button class="btn primary" type="submit" style="flex:0 0 auto">Upload</button></form>
        <p class="hint">Uploading again creates a new version; earlier versions are kept.</p>` : ''}
    </div>
    <div class="grid cols-2">
      <div><h3>Workflow history</h3>${history.length ? `<ul class="timeline">${history.map((h) => `<li>${badge(h.status)} <span class="muted">${esc(String(h.change_date).slice(0, 16))}</span></li>`).join('')}</ul>` : '<p class="muted">No history.</p>'}</div>
      <div><h3>Board decisions &amp; approvals</h3>
        ${decisions.map((x) => `<p style="margin:4px 0">${fmtDate(x.meeting_date)}: ${badge(x.decision)}</p>`).join('')}
        ${approvals.map((x) => `<p style="margin:4px 0">${badge(x.decision)} <span class="muted">${esc(x.hod)}, ${fmtDate(x.approved_at)}</span>${x.comments ? `<br><span class="muted">${esc(x.comments)}</span>` : ''}</p>`).join('')}
        ${!decisions.length && !approvals.length ? '<p class="muted">None yet.</p>' : ''}
      </div>
    </div>
    <div class="actions" id="paperActions"></div>`, { wide: true });

  const act = $('#paperActions', body);
  const addBtn = (label, cls, fn) => { const b = document.createElement('button'); b.className = 'btn ' + cls; b.textContent = label; b.addEventListener('click', fn); act.appendChild(b); };
  if (mine && p.status === 'Paper setting')
    addBtn('Submit for moderation', 'primary', async () => { try { await api(`/api/papers/${id}/submit`, { method: 'POST', body: {} }); toast('Paper submitted'); closeModal(); go('papers'); } catch (e) { fail(e); } });
  if (isHod() && p.status === 'Under moderation') {
    addBtn('Approve', 'primary', () => approvalForm(id, 'Approved'));
    addBtn('Request revision', 'danger', () => approvalForm(id, 'Revision requested'));
  }
  if ((isHod() || isAdmin()) && p.status === 'Approved')
    addBtn('Send to final printing', 'primary', async () => { try { await api(`/api/papers/${id}/print`, { method: 'POST', body: {} }); toast('Sent to final printing'); closeModal(); go('papers'); } catch (e) { fail(e); } });

  const uf = $('#upForm', body);
  if (uf) uf.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { const r = await api(`/api/papers/${id}/documents`, { method: 'POST', form: new FormData(uf) }); toast(`Uploaded (version ${r.version}). Documents: ${r.docs_count}/3`); openPaper(id); }
    catch (er) { fail(er); }
  });
}

function approvalForm(id, decision) {
  const body = modal(decision === 'Approved' ? 'Approve paper' : 'Request revision', `
    <form id="apForm" class="stack">
      <label>Comments${decision === 'Approved' ? ' (optional)' : ''}<textarea name="comments" ${decision === 'Approved' ? '' : 'required'}></textarea></label>
      <p id="apErr" class="error"></p>
      <div class="actions"><button class="btn primary" type="submit">Confirm</button></div></form>`);
  $('#apForm', body).addEventListener('submit', async (e) => {
    e.preventDefault();
    try { await api(`/api/papers/${id}/approve`, { method: 'POST', body: { decision, comments: new FormData(e.target).get('comments') } }); closeModal(); toast('Decision recorded'); go('papers'); }
    catch (er) { $('#apErr').textContent = er.message; }
  });
}

// ------------------------------------------------------------------ meetings
VIEWS.meetings = async (el) => {
  const ms = await api('/api/meetings');
  el.innerHTML = `<div class="toolbar"><span class="grow"></span>${isHod() || isAdmin() ? '<button class="btn primary" id="newMeeting">Schedule meeting</button>' : ''}</div><div id="mt"></div>`;
  $('#mt', el).innerHTML = table([
    { h: 'Date', f: (m) => `<b>${fmtDate(m.meeting_date)}</b>` },
    { h: 'Board', f: (m) => esc(m.board_name) },
    { h: 'Venue', f: (m) => `${esc(m.venue || '-')} <span class="muted">(${esc(m.mode)})</span>` },
    { h: 'Agenda', f: (m) => m.agenda_items + ' paper(s)' },
    { h: 'Quorum', f: (m) => `${m.present} / ${m.quorum}` },
    { h: 'Status', f: (m) => badge(m.status) },
  ], ms, { onRow: true, empty: 'No meetings yet.' });
  bindRows(el, ms, (m) => openMeeting(m.meeting_id));
  const nb = $('#newMeeting', el);
  if (nb) nb.addEventListener('click', scheduleForm);
};

async function scheduleForm() {
  const L = await lookups(true);
  const body = modal('Schedule scrutiny board meeting', `
    <form id="smForm" class="stack">
      <div class="row">
        <label>Board<select name="board_id" id="smBoard" required>${opts(L.boards, 'board_id', 'board_name', L.boards[0]?.board_id)}</select></label>
        <label>Date<input type="date" name="meeting_date" id="smDate" required></label>
      </div>
      <div><span class="hint">Suggested dates (weekdays with no exam, clash or unavailable member):</span><div class="chips" id="smSuggest"></div></div>
      <div class="row">
        <label>Venue<input name="venue" placeholder="e.g. Faculty Board Room"></label>
        <label>Mode<select name="mode"><option>Physical</option><option>Online</option></select></label>
        <label>Quorum<input type="number" min="1" name="quorum" value="3"></label>
      </div>
      <div><span class="hint">Papers for the agenda (only submitted papers with all 3 documents are accepted):</span><div id="smPapers" class="stack" style="gap:4px"></div></div>
      <p id="smErr" class="error"></p>
      <div class="actions"><button class="btn primary" type="submit">Schedule &amp; invite members</button></div>
    </form>`);
  const loadBoard = async () => {
    const bid = $('#smBoard', body).value;
    const [sd, papers] = await Promise.all([api('/api/suggest-dates?board_id=' + bid), api('/api/papers')]);
    $('#smSuggest', body).innerHTML = sd.length ? sd.map((x) => `<button type="button" class="chip" data-d="${esc(x.date)}">${esc(x.date)} ${esc(x.day.slice(0, 3))}</button>`).join('') : '<span class="muted">No free date in the next 30 days.</span>';
    $('#smSuggest', body).querySelectorAll('.chip').forEach((c) => c.addEventListener('click', () => ($('#smDate', body).value = c.dataset.d)));
    const el = papers.filter((p) => String(p.board_id) === String(bid) && ['Submitted', 'Under moderation'].includes(p.status));
    $('#smPapers', body).innerHTML = el.length ? el.map((p) => `<label style="flex-direction:row;align-items:center;gap:8px;font-weight:400;color:var(--text)"><input type="checkbox" style="width:auto" value="${p.paper_id}"> ${esc(p.title)} ${badge(p.status)} ${p.docs_count < 3 ? '<span class="badge bad">documents missing</span>' : ''}</label>`).join('') : '<span class="muted">No submitted papers for this board.</span>';
  };
  $('#smBoard', body).addEventListener('change', loadBoard);
  loadBoard().catch(fail);
  $('#smForm', body).addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    f.papers = [...body.querySelectorAll('#smPapers input:checked')].map((c) => +c.value);
    try {
      const r = await postWithWarnings('/api/meetings', f);
      if (!r) return;
      closeModal(); toast('Meeting scheduled; invitations sent');
      if (r.rejected && r.rejected.length) alert('Not added to the agenda:\n- ' + r.rejected.join('\n- '));
      go('meetings');
    } catch (er) { $('#smErr').textContent = er.message; }
  });
}

async function openMeeting(id) {
  const d = await api('/api/meetings/' + id).catch((e) => { fail(e); return null; });
  if (!d) return;
  const { meeting: m, agenda, members, eligible } = d;
  const open = m.status === 'Scheduled';
  const canDecide = (isHod() || role() === 'Moderator');
  const canMark = isHod() || isAdmin() || role() === 'Moderator';
  const present = members.filter((x) => x.present).length;
  const body = modal(`${m.board_name} - ${m.meeting_date}`, `
    <dl class="kv"><dt>Venue</dt><dd>${esc(m.venue || '-')} (${esc(m.mode)})</dd><dt>Status</dt><dd>${badge(m.status)}</dd>
      <dt>Quorum</dt><dd>${present} present of ${m.quorum} required ${present >= m.quorum ? '<span class="badge ok">met</span>' : '<span class="badge warn">not met</span>'}</dd></dl>
    <div><h3>Agenda</h3>
      ${agenda.length ? `<div class="table-wrap"><table><thead><tr><th>Paper</th><th>Stage</th><th>Decision</th>${canDecide ? '<th>Record decision</th>' : ''}</tr></thead><tbody>
        ${agenda.map((a) => `<tr><td>${esc(a.title)}</td><td>${badge(a.status)}</td><td>${badge(a.decision)}</td>
          ${canDecide ? `<td><select data-p="${a.paper_id}" class="dec"><option value="">Choose...</option><option>Accepted</option><option>Minor faults</option><option>Major faults</option></select></td>` : ''}</tr>`).join('')}
        </tbody></table></div>` : '<p class="muted">No papers on the agenda.</p>'}
      ${open && (isHod() || isAdmin()) && eligible.length ? `<form id="agForm" class="row" style="margin-top:10px;align-items:end"><label>Add paper<select name="paper">${eligible.map((p) => `<option value="${p.paper_id}">${esc(p.title)}</option>`).join('')}</select></label><button class="btn" type="submit" style="flex:0 0 auto">Add to agenda</button></form>` : ''}
    </div>
    <div><h3>Attendance</h3>
      <div class="table-wrap"><table><thead><tr><th>Member</th><th>Availability</th><th>Attendance</th></tr></thead><tbody>
      ${members.map((x) => `<tr><td>${esc(x.name)}</td><td>${x.available === 0 ? '<span class="badge bad">unavailable</span>' : x.available === 1 ? '<span class="badge ok">available</span>' : '<span class="muted">not set</span>'}</td>
        <td>${x.present === 1 ? '<span class="badge ok">Present</span>' : x.present === 0 ? '<span class="badge bad">Absent</span>' : '<span class="muted">not recorded</span>'}
        ${(canMark || (role() === 'Board Member' && x.user_id === state.user.id)) ? ` <button class="btn small att" data-u="${x.user_id}" data-p="1">Present</button> <button class="btn small att" data-u="${x.user_id}" data-p="0">Absent</button>` : ''}</td></tr>`).join('')}
      </tbody></table></div></div>
    <div class="actions" id="mtActions"></div>`, { wide: true });

  body.querySelectorAll('.dec').forEach((s) => s.addEventListener('change', async () => {
    if (!s.value) return;
    try { await api(`/api/meetings/${id}/decision`, { method: 'POST', body: { paper_id: +s.dataset.p, decision: s.value } }); toast('Decision recorded'); openMeeting(id); } catch (e) { fail(e); }
  }));
  body.querySelectorAll('.att').forEach((b) => b.addEventListener('click', async () => {
    try { const r = await api(`/api/meetings/${id}/attendance`, { method: 'POST', body: { user_id: +b.dataset.u, present: b.dataset.p === '1' } }); toast(`Present: ${r.present} / quorum ${r.quorum}${r.quorumMet ? ' (met)' : ''}`); openMeeting(id); } catch (e) { fail(e); }
  }));
  const ag = $('#agForm', body);
  if (ag) ag.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { const r = await api(`/api/meetings/${id}/agenda`, { method: 'POST', body: { papers: [+new FormData(ag).get('paper')] } }); if (r.rejected.length) alert('Not added:\n- ' + r.rejected.join('\n- ')); openMeeting(id); } catch (er) { fail(er); }
  });
  if (open && (isHod() || isAdmin())) {
    const act = $('#mtActions', body);
    for (const [label, status, cls] of [['Mark completed', 'Completed', 'primary'], ['Cancel meeting', 'Cancelled', 'danger']]) {
      const b = document.createElement('button'); b.className = 'btn ' + cls; b.textContent = label;
      b.addEventListener('click', async () => { try { const r = await postWithWarnings(`/api/meetings/${id}/status`, { status }); if (r) { closeModal(); toast('Meeting ' + status.toLowerCase()); go('meetings'); } } catch (e) { fail(e); } });
      act.appendChild(b);
    }
  }
}

// ------------------------------------------------------------------ timetable & readiness
VIEWS.timetable = async (el) => {
  const rows = await api('/api/timetable');
  el.innerHTML = `<div class="toolbar"><span class="grow"></span>${isHod() || isAdmin() ? '<button class="btn primary" id="slotBtn">Add / change slot</button>' : ''}</div><div id="tt"></div>`;
  $('#tt', el).innerHTML = table([
    { h: 'Date', f: (r) => `<b>${fmtDate(r.exam_date)}</b><br><span class="muted">${esc(r.day)}</span>` },
    { h: 'Time', f: (r) => `${esc(r.start_time)} - ${esc(r.end_time)}` },
    { h: 'Paper', f: (r) => `${esc(r.title)}<br><span class="muted">${esc(r.dept_name)} &middot; Sem ${esc(r.semester)}</span>` },
    { h: 'Venue', f: (r) => esc(r.venue || '-') },
    { h: 'Invigilator', f: (r) => esc(r.invigilator || '-') },
    { h: 'Paper status', f: (r) => badge(r.status) },
    ...(isHod() || isAdmin() ? [{ h: '', f: (r) => `<button class="btn small" data-edit="${r.paper_id}">Edit</button> <button class="btn small danger" data-del="${r.paper_id}">Remove</button>` }] : []),
  ], rows, { empty: 'The timetable is empty.' });
  el.querySelectorAll('[data-edit]').forEach((b) => b.addEventListener('click', () => slotForm(rows.find((r) => r.paper_id === +b.dataset.edit))));
  el.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm('Remove this exam from the timetable?')) return;
    try { await api('/api/timetable/' + b.dataset.del, { method: 'DELETE' }); toast('Removed'); go('timetable'); } catch (e) { fail(e); }
  }));
  const sb = $('#slotBtn', el);
  if (sb) sb.addEventListener('click', () => slotForm(null));
};

async function slotForm(row) {
  const L = await lookups(true);
  const papers = await api('/api/papers');
  const r = row || {};
  const body = modal('Examination timetable slot', `
    <form id="slForm" class="stack">
      <label>Paper<select name="paper_id" required>${opts(papers.map((p) => ({ id: p.paper_id, t: p.title })), 'id', 't', r.paper_id, 'Choose...')}</select></label>
      <div class="row"><label>Date<input type="date" name="exam_date" required value="${esc(r.exam_date || '')}"></label>
        <label>Start<input type="time" name="start_time" required value="${esc(r.start_time || '09:00')}"></label>
        <label>End<input type="time" name="end_time" required value="${esc(r.end_time || '12:00')}"></label></div>
      <div class="row"><label>Venue<input name="venue" value="${esc(r.venue || '')}"></label>
        <label>Invigilator<select name="invigilator_id">${opts(L.staff, 'user_id', 'name', r.invigilator_id, 'None')}</select></label></div>
      <p class="hint">Clashes (venue, invigilator, same department and semester) are rejected automatically.</p>
      <p id="slErr" class="error"></p>
      <div class="actions"><button class="btn primary" type="submit">Save slot</button></div>
    </form>`);
  $('#slForm', body).addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    try { const res = await postWithWarnings('/api/timetable', f); if (res) { closeModal(); toast('Slot saved'); go('timetable'); } }
    catch (er) { $('#slErr').textContent = er.message; }
  });
}

VIEWS.readiness = async (el) => {
  const rows = await api('/api/readiness');
  el.innerHTML = '<p class="muted">Compares each paper&rsquo;s scrutiny stage with its exam date. A paper is <b>at risk</b> when the exam is within 21 days and it is not yet approved.</p><div id="rd"></div>';
  $('#rd', el).innerHTML = table([
    { h: 'Paper', f: (r) => `<b>${esc(r.title)}</b>` }, { h: 'Exam date', f: (r) => fmtDate(r.exam_date) },
    { h: 'Days left', f: (r) => (r.days_left === null ? '-' : esc(r.days_left)) }, { h: 'Stage', f: (r) => badge(r.status) }, { h: 'Readiness', f: (r) => badge(r.readiness) },
  ], rows, { onRow: true });
  bindRows(el, rows, (r) => openPaper(r.paper_id));
};

// ------------------------------------------------------------------ boards
VIEWS.boards = async (el) => {
  const L = await lookups(true);
  const staff = L.staff;
  el.innerHTML = L.boards.map((b) => `<div class="card" style="margin-bottom:16px" data-b="${b.board_id}"><div class="toolbar" style="margin:0 0 8px"><h3 style="margin:0">${esc(b.board_name)}</h3><span class="grow"></span>
    <select class="addSel" style="max-width:220px">${opts(staff, 'user_id', 'name', '', 'Add member...')}</select></div><div class="members muted">Loading...</div></div>`).join('') || '<p class="muted">No boards.</p>';
  for (const card of el.querySelectorAll('[data-b]')) {
    const bid = card.dataset.b;
    const load = async () => {
      const ms = await api(`/api/admin/boards/${bid}/members`);
      $('.members', card).innerHTML = ms.length ? `<div class="chips">${ms.map((m) => `<span class="chip" style="cursor:default">${esc(m.name)} <a href="#" data-rm="${m.user_id}" title="Remove" style="text-decoration:none;color:var(--bad)">&times;</a></span>`).join('')}</div>` : 'No members.';
      card.querySelectorAll('[data-rm]').forEach((a) => a.addEventListener('click', async (e) => { e.preventDefault(); try { await api(`/api/admin/boards/${bid}/members/${a.dataset.rm}`, { method: 'DELETE' }); load(); } catch (er) { fail(er); } }));
    };
    load().catch(fail);
    $('.addSel', card).addEventListener('change', async (e) => { if (!e.target.value) return; try { await api(`/api/admin/boards/${bid}/members`, { method: 'POST', body: { user_id: +e.target.value } }); e.target.value = ''; load(); } catch (er) { fail(er); } });
  }
};

// ------------------------------------------------------------------ reports
VIEWS.reports = async (el) => {
  const list = await api('/api/reports');
  const cur = VIEWS.reports.cur || list[0].key;
  const rep = await api('/api/reports/' + cur);
  el.innerHTML = `<div class="toolbar"><div class="tabs">${list.map((r) => `<button class="tab" aria-pressed="${r.key === cur}" data-k="${r.key}">${esc(r.title)}</button>`).join('')}</div><span class="grow"></span>
    <a class="btn" href="/api/reports/${cur}?format=csv">Download CSV</a><button class="btn" onclick="window.print()">Print</button></div>
    <h3>${esc(rep.title)}</h3><div id="rp"></div>`;
  const cols = rep.rows.length ? Object.keys(rep.rows[0]) : [];
  $('#rp', el).innerHTML = table(cols.map((c) => ({ h: c.replace(/_/g, ' '), f: (r) => (BADGE[r[c]] ? badge(r[c]) : esc(r[c] ?? '-')) })), rep.rows, { empty: 'No data for this report.' });
  el.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => { VIEWS.reports.cur = b.dataset.k; go('reports'); }));
};

// ------------------------------------------------------------------ availability / notifications / account
VIEWS.availability = async (el) => {
  const rows = await api('/api/availability');
  el.innerHTML = `<div class="card" style="margin-bottom:16px"><h3>Mark a date</h3>
    <p class="muted">Board meeting scheduling and invigilator assignment take these dates into account.</p>
    <form id="avForm" class="row" style="align-items:end"><label>Date<input type="date" name="date" required></label>
      <label>Status<select name="available"><option value="0">Unavailable</option><option value="1">Available</option></select></label>
      <button class="btn primary" style="flex:0 0 auto">Save</button></form></div><div id="av"></div>`;
  $('#av', el).innerHTML = table([
    { h: 'Date', f: (r) => fmtDate(r.available_date) }, { h: 'Status', f: (r) => (r.is_available ? '<span class="badge ok">Available</span>' : '<span class="badge bad">Unavailable</span>') },
    { h: '', f: (r) => `<button class="btn small danger" data-d="${esc(String(r.available_date).slice(0, 10))}">Remove</button>` },
  ], rows, { empty: 'No dates marked.' });
  $('#avForm', el).addEventListener('submit', async (e) => { e.preventDefault(); const f = new FormData(e.target); try { await api('/api/availability', { method: 'POST', body: { date: f.get('date'), available: f.get('available') === '1' } }); toast('Saved'); go('availability'); } catch (er) { fail(er); } });
  el.querySelectorAll('[data-d]').forEach((b) => b.addEventListener('click', async () => { try { await api('/api/availability/' + b.dataset.d, { method: 'DELETE' }); go('availability'); } catch (e) { fail(e); } }));
};

VIEWS.notifications = async (el) => {
  const rows = await api('/api/notifications');
  const unread = rows.filter((r) => !r.read_at).length;
  el.innerHTML = `<div class="toolbar"><span class="muted">${unread} unread</span><span class="grow"></span><button class="btn" id="readAll" ${unread ? '' : 'disabled'}>Mark all as read</button></div>
    <div class="card">${rows.length ? rows.map((n) => `<div class="notif ${n.read_at ? '' : 'unread'}"><span class="badge info">${esc(n.type || 'Info')}</span><div style="flex:1">${esc(n.message)}<div class="muted" style="font-weight:400;font-size:12px">${esc(String(n.sent_at).slice(0, 16))}</div></div></div>`).join('') : '<p class="muted">No notifications.</p>'}</div>`;
  $('#readAll', el).addEventListener('click', async () => { try { await api('/api/notifications/read', { method: 'POST', body: {} }); go('notifications'); } catch (e) { fail(e); } });
};

VIEWS.account = async (el) => {
  const u = state.user;
  el.innerHTML = `<div class="grid cols-2"><div class="card"><h3>Profile</h3><dl class="kv"><dt>Name</dt><dd>${esc(u.name)}</dd><dt>Email</dt><dd>${esc(u.email)}</dd><dt>Department</dt><dd>${esc(u.deptName || 'Faculty-wide')}</dd><dt>Roles</dt><dd>${u.roles.map(esc).join(', ')}</dd></dl></div>
    <div class="card"><h3>Change password</h3><form id="cpForm" class="stack"><label>Current password<input type="password" name="current" autocomplete="current-password" required></label>
      <label>New password<input type="password" name="password" autocomplete="new-password" required minlength="8"></label>
      <label>Confirm new password<input type="password" name="confirm" autocomplete="new-password" required></label>
      <p id="cpErr" class="error"></p><div class="actions"><button class="btn primary">Update password</button></div></form></div></div>`;
  $('#cpForm', el).addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    if (f.password !== f.confirm) { $('#cpErr').textContent = 'Passwords do not match'; return; }
    try { await api('/api/change-password', { method: 'POST', body: { current: f.current, password: f.password } }); e.target.reset(); $('#cpErr').textContent = ''; toast('Password updated'); }
    catch (er) { $('#cpErr').textContent = er.message; }
  });
};

// ------------------------------------------------------------------ administration
VIEWS.users = async (el) => {
  const [users, L] = await Promise.all([api('/api/admin/users'), lookups(true)]);
  el.innerHTML = `<div class="toolbar"><p class="muted" style="margin:0">A * after a role means it is inactive.</p><span class="grow"></span><button class="btn primary" id="addUser">Add user</button></div><div id="ut"></div>`;
  $('#ut', el).innerHTML = table([
    { h: 'Name', f: (u) => `<b>${esc(u.name)}</b><br><span class="muted">${esc(u.email)}</span>` },
    { h: 'Department', f: (u) => esc(u.dept_name || '-') }, { h: 'Roles', f: (u) => esc(u.roles || '-') },
    { h: 'Security', f: (u) => (u.failed_attempts >= 5 ? '<span class="badge bad">Locked</span>' : u.must_change_password ? '<span class="badge warn">Must change password</span>' : '<span class="badge ok">OK</span>') },
    { h: '', f: (u) => `<button class="btn small" data-role="${u.user_id}">Roles</button> <button class="btn small" data-reset="${u.user_id}">Reset password</button>` },
  ], users);
  el.querySelectorAll('[data-reset]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm('Reset this password and unlock the account?')) return;
    try { const r = await api(`/api/admin/users/${b.dataset.reset}/reset-password`, { method: 'POST', body: {} }); modal('Temporary password', `<p>Give this to the user. They must change it at next sign-in.</p><p style="font-size:22px;font-family:monospace"><b>${esc(r.temporary_password)}</b></p>`); go('users'); } catch (e) { fail(e); }
  }));
  el.querySelectorAll('[data-role]').forEach((b) => b.addEventListener('click', () => roleForm(users.find((u) => u.user_id === +b.dataset.role), L)));
  $('#addUser', el).addEventListener('click', () => {
    const body = modal('Add user', `<form id="auForm" class="stack"><label>Name<input name="name" required></label><label>Email<input type="email" name="email" required></label>
      <div class="row"><label>Phone<input name="phone"></label><label>Department<select name="dept_id">${opts(L.departments, 'dept_id', 'dept_name', '', 'None')}</select></label></div>
      <label>Initial role<select name="role_id">${opts(L.roles, 'role_id', 'role_name', 2, 'None')}</select></label><p id="auErr" class="error"></p><div class="actions"><button class="btn primary">Create user</button></div></form>`);
    $('#auForm', body).addEventListener('submit', async (e) => {
      e.preventDefault();
      try { const r = await api('/api/admin/users', { method: 'POST', body: Object.fromEntries(new FormData(e.target)) }); modal('User created', `<p>Temporary password (shown once):</p><p style="font-size:22px;font-family:monospace"><b>${esc(r.temporary_password)}</b></p><p class="hint">The user must change it at first sign-in.</p>`); go('users'); }
      catch (er) { $('#auErr').textContent = er.message; }
    });
  });
};
function roleForm(u, L) {
  const body = modal('Roles for ' + u.name, `<p class="muted">Current: ${esc(u.roles || 'none')}</p><form id="rlForm" class="row" style="align-items:end"><label>Role<select name="role_id">${opts(L.roles, 'role_id', 'role_name', '')}</select></label>
    <label>Action<select name="active"><option value="1">Assign / activate</option><option value="0">Deactivate</option></select></label><button class="btn primary" style="flex:0 0 auto">Apply</button></form>`);
  $('#rlForm', body).addEventListener('submit', async (e) => {
    e.preventDefault(); const f = new FormData(e.target);
    try { await api(`/api/admin/users/${u.user_id}/roles`, { method: 'POST', body: { role_id: +f.get('role_id'), active: f.get('active') === '1' } }); closeModal(); toast('Role updated'); go('users'); } catch (er) { fail(er); }
  });
}

VIEWS.structure = async (el) => {
  const [s, L] = await Promise.all([api('/api/admin/structure'), lookups(true)]);
  el.innerHTML = `<div class="card" style="margin-bottom:16px"><div class="uni">${esc(s.faculty[0]?.university || '')}</div><h3 style="margin:2px 0 0;font-size:18px">${esc(s.faculty[0]?.faculty_name || '')}</h3></div>
    <div class="toolbar"><h3 style="margin:0">Departments</h3><span class="grow"></span><button class="btn" id="addDept">Add department</button></div>
    ${table([{ h: 'ID', f: (d) => d.dept_id }, { h: 'Department', f: (d) => esc(d.dept_name) }], s.departments)}
    <div class="toolbar" style="margin-top:24px"><h3 style="margin:0">Subjects</h3><span class="grow"></span><button class="btn" id="addSub">Add subject</button></div>
    ${table([{ h: 'Subject', f: (x) => esc(x.subject_name) }, { h: 'Department', f: (x) => esc(x.dept_name) }, { h: 'Semester', f: (x) => x.semester }, { h: 'Credits', f: (x) => x.credits }], s.subjects)}
    <div class="toolbar" style="margin-top:24px"><h3 style="margin:0">Scrutiny boards</h3><span class="grow"></span><button class="btn" id="addBoard">Add board</button></div>
    ${table([{ h: 'Board', f: (b) => esc(b.board_name) }, { h: 'Department', f: (b) => esc(b.dept_name) }, { h: 'Members', f: (b) => b.members }, { h: 'Status', f: (b) => badge(b.status) }], s.boards)}`;
  const simple = (id, title, fields, path, mk) => $(id, el).addEventListener('click', () => {
    const body = modal(title, `<form id="sf" class="stack">${fields}<p id="sfErr" class="error"></p><div class="actions"><button class="btn primary">Save</button></div></form>`);
    $('#sf', body).addEventListener('submit', async (e) => { e.preventDefault(); try { await api(path, { method: 'POST', body: mk(Object.fromEntries(new FormData(e.target))) }); closeModal(); toast('Saved'); go('structure'); } catch (er) { $('#sfErr').textContent = er.message; } });
  });
  simple('#addDept', 'Add department', '<label>Name<input name="name" required></label>', '/api/admin/departments', (f) => f);
  simple('#addSub', 'Add subject', `<label>Subject name<input name="subject_name" required></label><div class="row"><label>Department<select name="dept_id" required>${opts(L.departments, 'dept_id', 'dept_name', '', 'Choose...')}</select></label><label>Semester<input type="number" name="semester" min="1" max="8" value="1"></label><label>Credits<input type="number" name="credits" min="1" value="3"></label></div>`, '/api/admin/subjects', (f) => f);
  simple('#addBoard', 'Add scrutiny board', `<label>Board name<input name="board_name" required></label><label>Department<select name="dept_id" required>${opts(L.departments, 'dept_id', 'dept_name', '', 'Choose...')}</select></label>`, '/api/admin/boards', (f) => f);
};

// ------------------------------------------------------------------ auth flow
function showAuth(step = 'login') {
  $('#shell').classList.add('hidden'); $('#auth').classList.remove('hidden'); closeModal();
  $('#loginForm').classList.toggle('hidden', step !== 'login');
  $('#rolePicker').classList.toggle('hidden', step !== 'role');
  $('#forcePwForm').classList.toggle('hidden', step !== 'password');
  $('#authError').textContent = '';
  if (step === 'login') $('#loginPassword').value = '';
}
async function enterApp() {
  const { user } = await api('/api/me');
  if (!user) return showAuth();
  state.user = user; state.lookups = null;
  if (user.mustChange) return showAuth('password');
  if (!user.role) {
    $('#roleButtons').innerHTML = user.roles.map((r) => `<button class="btn" data-r="${esc(r)}">${esc(r)}</button>`).join('');
    $('#roleButtons').querySelectorAll('button').forEach((b) => b.addEventListener('click', async () => { try { await api('/api/select-role', { method: 'POST', body: { role: b.dataset.r } }); enterApp(); } catch (e) { $('#authError').textContent = e.message; } }));
    return showAuth('role');
  }
  $('#auth').classList.add('hidden'); $('#shell').classList.remove('hidden');
  $('#whoName').textContent = user.name; $('#whoRole').textContent = user.role + (user.deptName ? ' - ' + user.deptName : '');
  $('#switchBtn').classList.toggle('hidden', user.roles.length < 2);
  buildNav(); go('dashboard');
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault(); $('#authError').textContent = '';
  try { await api('/api/login', { method: 'POST', body: { email: $('#loginEmail').value, password: $('#loginPassword').value } }); await enterApp(); }
  catch (er) { $('#authError').textContent = er.message; }
});
$('#forcePwForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if ($('#fpNew').value !== $('#fpConfirm').value) { $('#authError').textContent = 'Passwords do not match'; return; }
  try { await api('/api/change-password', { method: 'POST', body: { password: $('#fpNew').value } }); $('#fpNew').value = $('#fpConfirm').value = ''; await enterApp(); }
  catch (er) { $('#authError').textContent = er.message; }
});
$('#logoutBtn').addEventListener('click', async () => { await api('/api/logout', { method: 'POST', body: {} }).catch(() => {}); state.user = null; showAuth(); });
$('#switchBtn').addEventListener('click', async () => { state.user.role = null; try { await api('/api/select-role', { method: 'POST', body: { role: '' } }); } catch { /* roles reselect below */ } enterApp(); });
$('#bellBtn').addEventListener('click', () => go('notifications'));
$('#menuBtn').addEventListener('click', () => $('#sidebar').classList.toggle('open'));

enterApp().catch(() => showAuth());
