// Creates the ScrutinyBoardDB database with the Rajarata FAS sample data.
// Usage: npm run setup-db        (env: DB_HOST, DB_PORT, DB_USER, DB_PASS)
const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

(async () => {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: +process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || '1234',
    multipleStatements: true,
  });
  try {
    const sql = fs.readFileSync(path.join(__dirname, 'FAS_Setup.sql'), 'utf8');
    await conn.query(sql);
    console.log('Database ScrutinyBoardDB created and sample data loaded.');
    console.log('Sample logins use the password Rusl@2026 (see README).');
  } catch (e) {
    console.error('Setup failed:', e.sqlMessage || e.message);
    process.exitCode = 1;
  } finally {
    await conn.end();
  }
})();
