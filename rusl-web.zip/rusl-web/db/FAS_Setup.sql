-- =====================================================================
--  Scrutiny Board Management System
--  Rajarata University of Sri Lanka - Faculty of Applied Sciences
--  One-file setup: schema + sample data.   Requires MySQL 8.0+
--  WARNING: drops and recreates the ScrutinyBoardDB database.
--  Sample password for every account: Rusl@2026
--  (Staff names and departments below are SAMPLE data - edit as needed.)
-- =====================================================================
DROP DATABASE IF EXISTS ScrutinyBoardDB;
CREATE DATABASE ScrutinyBoardDB CHARACTER SET utf8mb4;
USE ScrutinyBoardDB;

-- ----------------------------------------------------------------- schema
CREATE TABLE FACULTY (
    faculty_id    INT AUTO_INCREMENT PRIMARY KEY,
    faculty_name  VARCHAR(120) NOT NULL UNIQUE,
    university    VARCHAR(120) NOT NULL
);

CREATE TABLE DEPARTMENT (
    dept_id     INT AUTO_INCREMENT PRIMARY KEY,
    dept_name   VARCHAR(100) NOT NULL UNIQUE,
    faculty_id  INT,
    CONSTRAINT fk_dept_faculty FOREIGN KEY (faculty_id)
        REFERENCES FACULTY(faculty_id) ON DELETE SET NULL
);

CREATE TABLE ROLE (
    role_id     INT AUTO_INCREMENT PRIMARY KEY,
    role_name   VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE USERS (
    user_id              INT AUTO_INCREMENT PRIMARY KEY,
    name                 VARCHAR(100) NOT NULL,
    email                VARCHAR(100) NOT NULL UNIQUE,
    phone                VARCHAR(15),
    dept_id              INT,
    salt                 CHAR(16),
    password_hash        CHAR(64),                 -- SHA2(salt + password, 256)
    must_change_password BOOLEAN NOT NULL DEFAULT TRUE,
    failed_attempts      INT NOT NULL DEFAULT 0,   -- account locks at 5
    CONSTRAINT fk_users_dept FOREIGN KEY (dept_id)
        REFERENCES DEPARTMENT(dept_id) ON DELETE SET NULL
);

CREATE TABLE USER_ROLE (
    user_id         INT,
    role_id         INT,
    assigned_date   DATE NOT NULL,
    is_active       BOOLEAN DEFAULT TRUE,
    PRIMARY KEY (user_id, role_id),
    CONSTRAINT fk_ur_user FOREIGN KEY (user_id) REFERENCES USERS(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_ur_role FOREIGN KEY (role_id) REFERENCES ROLE(role_id) ON DELETE CASCADE
);

CREATE TABLE SUBJECT (
    subject_id      INT AUTO_INCREMENT PRIMARY KEY,
    subject_name    VARCHAR(100) NOT NULL,
    credits         INT CHECK (credits > 0),
    semester        INT,
    dept_id         INT NOT NULL,
    CONSTRAINT fk_subject_dept FOREIGN KEY (dept_id) REFERENCES DEPARTMENT(dept_id)
);

CREATE TABLE SCRUTINY_BOARD (
    board_id        INT AUTO_INCREMENT PRIMARY KEY,
    board_name      VARCHAR(100) NOT NULL,
    status          VARCHAR(20) DEFAULT 'Active',
    dept_id         INT NOT NULL,
    CONSTRAINT fk_board_dept FOREIGN KEY (dept_id) REFERENCES DEPARTMENT(dept_id)
);

CREATE TABLE BOARD_MEMBER (
    user_id     INT,
    board_id    INT,
    PRIMARY KEY (user_id, board_id),
    CONSTRAINT fk_bm_user  FOREIGN KEY (user_id)  REFERENCES USERS(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_bm_board FOREIGN KEY (board_id) REFERENCES SCRUTINY_BOARD(board_id) ON DELETE CASCADE
);

CREATE TABLE BOARD_MEETING (
    meeting_id      INT AUTO_INCREMENT PRIMARY KEY,
    meeting_date    DATE NOT NULL,
    venue           VARCHAR(100),
    mode            VARCHAR(20),
    quorum          INT,
    status          VARCHAR(20) DEFAULT 'Scheduled',
    board_id        INT NOT NULL,
    CONSTRAINT fk_meeting_board FOREIGN KEY (board_id)
        REFERENCES SCRUTINY_BOARD(board_id) ON DELETE CASCADE
);

CREATE TABLE MEMBER_ATTENDANCE (
    attendance_id   INT AUTO_INCREMENT PRIMARY KEY,
    present         BOOLEAN DEFAULT FALSE,
    join_time       DATETIME,
    leave_time      DATETIME,
    meeting_id      INT NOT NULL,
    user_id         INT NOT NULL,
    CONSTRAINT fk_att_meeting FOREIGN KEY (meeting_id) REFERENCES BOARD_MEETING(meeting_id) ON DELETE CASCADE,
    CONSTRAINT fk_att_user    FOREIGN KEY (user_id)    REFERENCES USERS(user_id) ON DELETE CASCADE
);

CREATE TABLE EXAM (
    exam_id         INT AUTO_INCREMENT PRIMARY KEY,
    exam_name       VARCHAR(120),
    exam_time       TIME,
    start_date      DATE,
    status          VARCHAR(20),
    board_id        INT,
    CONSTRAINT fk_exam_board FOREIGN KEY (board_id)
        REFERENCES SCRUTINY_BOARD(board_id) ON DELETE SET NULL
);

CREATE TABLE EXAM_PAPER (
    paper_id            INT AUTO_INCREMENT PRIMARY KEY,
    title               VARCHAR(150) NOT NULL,
    exam_date           DATE,
    status              VARCHAR(30) DEFAULT 'Paper setting',
    submission_deadline DATE,
    subject_id          INT NOT NULL,
    exam_id             INT,
    board_id            INT,
    prepared_by         INT,
    CONSTRAINT fk_paper_subject FOREIGN KEY (subject_id) REFERENCES SUBJECT(subject_id),
    CONSTRAINT fk_paper_exam    FOREIGN KEY (exam_id)    REFERENCES EXAM(exam_id) ON DELETE SET NULL,
    CONSTRAINT fk_paper_board   FOREIGN KEY (board_id)   REFERENCES SCRUTINY_BOARD(board_id) ON DELETE SET NULL,
    CONSTRAINT fk_paper_user    FOREIGN KEY (prepared_by) REFERENCES USERS(user_id) ON DELETE SET NULL
);

CREATE TABLE PAPER_STATUS_HISTORY (
    history_id      INT AUTO_INCREMENT PRIMARY KEY,
    status          VARCHAR(30) NOT NULL,
    change_date     DATETIME DEFAULT CURRENT_TIMESTAMP,
    paper_id        INT NOT NULL,
    CONSTRAINT fk_hist_paper FOREIGN KEY (paper_id) REFERENCES EXAM_PAPER(paper_id) ON DELETE CASCADE
);

CREATE TABLE HOD_APPROVAL (
    approval_id     INT AUTO_INCREMENT PRIMARY KEY,
    decision        VARCHAR(20) NOT NULL,
    comments        TEXT,
    approved_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
    paper_id        INT NOT NULL,
    hod_id          INT NOT NULL,
    CONSTRAINT fk_appr_paper FOREIGN KEY (paper_id) REFERENCES EXAM_PAPER(paper_id) ON DELETE CASCADE,
    CONSTRAINT fk_appr_user  FOREIGN KEY (hod_id)   REFERENCES USERS(user_id)
);

CREATE TABLE MEETING_DECISION (
    meeting_id      INT,
    paper_id        INT,
    decision        VARCHAR(30),
    PRIMARY KEY (meeting_id, paper_id),
    CONSTRAINT fk_md_meeting FOREIGN KEY (meeting_id) REFERENCES BOARD_MEETING(meeting_id) ON DELETE CASCADE,
    CONSTRAINT fk_md_paper   FOREIGN KEY (paper_id)   REFERENCES EXAM_PAPER(paper_id) ON DELETE CASCADE
);

CREATE TABLE DOCUMENT (
    doc_id          INT AUTO_INCREMENT PRIMARY KEY,
    doc_type        VARCHAR(30) NOT NULL,       -- Question Paper / Marking Scheme / Moderator Report
    submitted_date  DATE,
    submitted_by    INT NOT NULL,
    paper_id        INT,
    CONSTRAINT fk_doc_user  FOREIGN KEY (submitted_by) REFERENCES USERS(user_id),
    CONSTRAINT fk_doc_paper FOREIGN KEY (paper_id)     REFERENCES EXAM_PAPER(paper_id) ON DELETE CASCADE
);

CREATE TABLE DOCUMENT_VERSION (
    version_id      INT AUTO_INCREMENT PRIMARY KEY,
    version_no      INT NOT NULL,
    file_path       VARCHAR(255) NOT NULL,
    uploaded_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
    doc_id          INT NOT NULL,
    CONSTRAINT fk_ver_doc FOREIGN KEY (doc_id) REFERENCES DOCUMENT(doc_id) ON DELETE CASCADE
);

CREATE TABLE NOTIFICATION (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    type            VARCHAR(30),
    message         VARCHAR(255) NOT NULL,
    sent_at         DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at         DATETIME,
    user_id         INT NOT NULL,
    CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES USERS(user_id) ON DELETE CASCADE
);

CREATE TABLE LECTURER_AVAILABILITY (
    availability_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    available_date  DATE NOT NULL,
    is_available    BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE KEY uq_user_date (user_id, available_date),
    CONSTRAINT fk_avail_user FOREIGN KEY (user_id) REFERENCES USERS(user_id) ON DELETE CASCADE
);

CREATE TABLE EXAM_TIMETABLE (
    slot_id         INT AUTO_INCREMENT PRIMARY KEY,
    paper_id        INT NOT NULL UNIQUE,
    exam_date       DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    venue           VARCHAR(100),
    invigilator_id  INT,
    CONSTRAINT fk_tt_paper FOREIGN KEY (paper_id) REFERENCES EXAM_PAPER(paper_id) ON DELETE CASCADE,
    CONSTRAINT fk_tt_inv   FOREIGN KEY (invigilator_id) REFERENCES USERS(user_id) ON DELETE SET NULL
);

-- ------------------------------------------------------------ sample data
INSERT INTO FACULTY (faculty_id, faculty_name, university) VALUES
(1, 'Faculty of Applied Sciences', 'Rajarata University of Sri Lanka');

INSERT INTO DEPARTMENT (dept_id, dept_name, faculty_id) VALUES
(1, 'Information and Communication Technology', 1),
(2, 'Mathematics', 1),
(3, 'Physical Sciences', 1),
(4, 'Biological Sciences', 1);

INSERT INTO ROLE (role_id, role_name) VALUES
(1, 'Head of Department'),
(2, 'Lecturer'),
(3, 'Moderator'),
(4, 'Board Member'),
(5, 'Administrator'),
(6, 'Paper Setter');

INSERT INTO USERS (user_id, name, email, phone, dept_id) VALUES
(1,  'Dr. Nimal Perera',          'nimal@as.rjt.ac.lk',    '0711234567', 1),
(2,  'Ms. Kamala Silva',          'kamala@as.rjt.ac.lk',   '0712345678', 1),
(3,  'Dr. Sunil Fernando',        'sunil@as.rjt.ac.lk',    '0713456789', 1),
(4,  'Prof. Anura Jayasinghe',    'anura@as.rjt.ac.lk',    '0714567890', 2),
(5,  'Ms. Dilani Wickramasinghe', 'dilani@as.rjt.ac.lk',   '0715678901', 2),
(6,  'Dr. Ruwan Bandara',         'ruwan@as.rjt.ac.lk',    '0716789012', 3),
(7,  'Ms. Nadeesha Karunaratne',  'nadeesha@as.rjt.ac.lk', '0717890123', 1),
(8,  'System Administrator',      'admin@as.rjt.ac.lk',    NULL,         NULL),
(9,  'Mr. Chamara Rathnayake',    'chamara@as.rjt.ac.lk',  '0718901234', 1),
(10, 'Dr. Sanduni Herath',        'sanduni@as.rjt.ac.lk',  '0719012345', 2),
(11, 'Mr. Tharindu Gamage',       'tharindu@as.rjt.ac.lk', '0710123456', 3),
(12, 'Dr. Iresha Abeysekara',     'iresha@as.rjt.ac.lk',   '0721234567', 4),
(13, 'Ms. Piumi Jayawardena',     'piumi@as.rjt.ac.lk',    '0722345678', 4),
(14, 'Dr. Lakmal Senanayake',     'lakmal@as.rjt.ac.lk',   '0723456789', 3),
(15, 'Dr. Ruwani Dissanayake',    'ruwani@as.rjt.ac.lk',   '0724567890', 4);

-- Passwords: per-user random salt, SHA-256 of salt+password. Sample password: Rusl@2026
UPDATE USERS SET salt = LEFT(MD5(CONCAT(user_id, RAND(), NOW(6))), 16);
UPDATE USERS SET password_hash = SHA2(CONCAT(salt, 'Rusl@2026'), 256), must_change_password = FALSE;

INSERT INTO USER_ROLE (user_id, role_id, assigned_date, is_active) VALUES
(1,1,'2024-01-10',TRUE), (1,4,'2024-02-01',TRUE),
(2,2,'2023-08-15',TRUE), (2,6,'2023-08-15',TRUE),
(3,3,'2024-01-20',TRUE), (3,4,'2024-02-01',TRUE),
(4,1,'2023-09-01',TRUE), (4,4,'2024-02-01',TRUE),
(5,2,'2023-08-20',TRUE), (5,6,'2023-08-20',TRUE), (5,4,'2024-02-01',TRUE),
(6,1,'2024-01-05',TRUE), (6,4,'2024-02-01',TRUE),
(7,2,'2024-03-01',TRUE), (7,4,'2024-02-01',TRUE),
(8,5,'2022-01-01',TRUE),
(9,2,'2024-03-01',TRUE), (9,6,'2024-03-01',TRUE),
(10,3,'2024-01-20',TRUE), (10,4,'2024-02-01',TRUE),
(11,2,'2023-09-10',TRUE), (11,6,'2023-09-10',TRUE), (11,4,'2024-02-01',TRUE),
(12,1,'2024-01-08',TRUE), (12,4,'2024-02-01',TRUE),
(13,2,'2023-09-12',TRUE), (13,6,'2023-09-12',TRUE), (13,4,'2024-02-01',TRUE),
(14,3,'2024-01-20',TRUE), (14,4,'2024-02-01',TRUE),
(15,3,'2024-01-20',TRUE), (15,4,'2024-02-01',TRUE);

INSERT INTO SUBJECT (subject_id, subject_name, credits, semester, dept_id) VALUES
(1,  'C Programming',     3, 1, 1),
(2,  'Electronics',       3, 1, 1),
(3,  'Probability',       2, 2, 2),
(4,  'Database Systems',  3, 2, 1),
(5,  'Calculus',          3, 1, 2),
(6,  'Mechanics',         2, 2, 3),
(7,  'Data Structures',   3, 2, 1),
(8,  'Linear Algebra',    3, 1, 2),
(9,  'Thermodynamics',    2, 2, 3),
(10, 'Cell Biology',      3, 1, 4),
(11, 'Genetics',          3, 2, 4);

INSERT INTO SCRUTINY_BOARD (board_id, board_name, status, dept_id) VALUES
(1, 'ICT Scrutiny Board',                 'Active', 1),
(2, 'Mathematics Scrutiny Board',         'Active', 2),
(3, 'Physical Sciences Scrutiny Board',   'Active', 3),
(4, 'Biological Sciences Scrutiny Board', 'Active', 4);

INSERT INTO BOARD_MEMBER (user_id, board_id) VALUES
(1,1), (3,1), (7,1),
(4,2), (5,2), (10,2),
(6,3), (14,3), (11,3),
(12,4), (13,4), (15,4);

INSERT INTO BOARD_MEETING (meeting_id, meeting_date, venue, mode, quorum, status, board_id) VALUES
(1, '2026-10-05', 'Faculty Board Room',   'Physical', 3, 'Completed', 1),
(2, '2026-10-28', 'Online',               'Online',   3, 'Scheduled', 1),
(3, '2026-10-08', 'Maths Seminar Room',   'Physical', 2, 'Completed', 2),
(4, '2026-11-03', 'Maths Seminar Room',   'Physical', 2, 'Scheduled', 2),
(5, '2026-11-04', 'Biology Seminar Room', 'Physical', 2, 'Scheduled', 4);

INSERT INTO MEMBER_ATTENDANCE (attendance_id, present, join_time, leave_time, meeting_id, user_id) VALUES
(1, TRUE,  '2026-10-05 09:00:00', '2026-10-05 11:00:00', 1, 1),
(2, TRUE,  '2026-10-05 09:05:00', '2026-10-05 11:00:00', 1, 3),
(3, FALSE, NULL,                  NULL,                  1, 7),
(4, TRUE,  '2026-10-08 10:00:00', '2026-10-08 11:30:00', 3, 4),
(5, TRUE,  '2026-10-08 10:02:00', '2026-10-08 11:30:00', 3, 5),
(6, TRUE,  '2026-10-08 10:03:00', '2026-10-08 11:30:00', 3, 10);

INSERT INTO EXAM (exam_id, exam_name, exam_time, start_date, status, board_id) VALUES
(1, 'Semester Examination 2026 - ICT',                 '09:00:00', '2026-11-20', 'Scheduled', 1),
(2, 'Semester Examination 2026 - Mathematics',         '13:30:00', '2026-11-25', 'Scheduled', 2),
(3, 'Semester Examination 2026 - Physical Sciences',   '09:00:00', '2026-12-04', 'Scheduled', 3),
(4, 'Semester Examination 2026 - Biological Sciences', '09:00:00', '2026-11-12', 'Scheduled', 4);

INSERT INTO EXAM_PAPER (paper_id, title, exam_date, status, submission_deadline, subject_id, exam_id, board_id, prepared_by) VALUES
(1,  'C Programming Final Paper',    '2026-11-20', 'Approved',         '2026-10-01', 1,  1, 1, 2),
(2,  'Database Systems Final Paper', '2026-12-01', 'Under moderation', '2026-10-05', 4,  1, 1, 2),
(3,  'Electronics Final Paper',      '2026-11-24', 'Paper setting',    '2026-10-20', 2,  1, 1, 9),
(4,  'Calculus Final Paper',         '2026-11-25', 'Approved',         '2026-10-05', 5,  2, 2, 5),
(5,  'Probability Final Paper',      '2026-12-02', 'Submitted',        '2026-10-15', 3,  2, 2, 5),
(6,  'Data Structures Final Paper',  '2026-12-03', 'Paper setting',    '2026-10-28', 7,  1, 1, 7),
(7,  'Linear Algebra Final Paper',   '2026-11-27', 'Final printing',   '2026-10-01', 8,  2, 2, 5),
(8,  'Mechanics Final Paper',        '2026-12-04', 'Submitted',        '2026-10-20', 6,  3, 3, 11),
(9,  'Thermodynamics Final Paper',   '2026-12-07', 'Paper setting',    '2026-10-30', 9,  3, 3, 11),
(10, 'Cell Biology Final Paper',     '2026-11-12', 'Under moderation', '2026-10-15', 10, 4, 4, 13),
(11, 'Genetics Final Paper',         '2026-12-08', 'Paper setting',    '2026-11-02', 11, 4, 4, 13);

INSERT INTO PAPER_STATUS_HISTORY (status, change_date, paper_id) VALUES
('Paper setting',    '2026-09-20 10:00:00', 1),
('Submitted',        '2026-10-01 14:30:00', 1),
('Under moderation', '2026-10-05 09:00:00', 1),
('Approved',         '2026-10-10 15:30:00', 1),
('Paper setting',    '2026-09-22 11:00:00', 2),
('Submitted',        '2026-10-02 15:00:00', 2),
('Under moderation', '2026-10-22 09:30:00', 2),
('Paper setting',    '2026-10-03 09:00:00', 3),
('Paper setting',    '2026-09-25 10:00:00', 4),
('Submitted',        '2026-10-02 10:00:00', 4),
('Under moderation', '2026-10-08 09:00:00', 4),
('Approved',         '2026-10-09 11:45:00', 4),
('Paper setting',    '2026-09-28 10:00:00', 5),
('Submitted',        '2026-10-12 10:00:00', 5),
('Paper setting',    '2026-10-10 10:00:00', 6),
('Paper setting',    '2026-09-25 10:00:00', 7),
('Submitted',        '2026-10-01 10:00:00', 7),
('Under moderation', '2026-10-08 09:00:00', 7),
('Approved',         '2026-10-12 12:00:00', 7),
('Final printing',   '2026-10-14 10:00:00', 7),
('Paper setting',    '2026-10-01 10:00:00', 8),
('Submitted',        '2026-10-20 11:00:00', 8),
('Paper setting',    '2026-10-12 10:00:00', 9),
('Paper setting',    '2026-10-05 10:00:00', 10),
('Submitted',        '2026-10-15 10:00:00', 10),
('Under moderation', '2026-10-23 09:00:00', 10),
('Paper setting',    '2026-10-15 10:00:00', 11);

INSERT INTO HOD_APPROVAL (approval_id, decision, comments, approved_at, paper_id, hod_id) VALUES
(1, 'Approved', 'Meets syllabus coverage.',             '2026-10-10 15:30:00', 1, 1),
(2, 'Approved', 'Good balance of easy and hard items.', '2026-10-09 11:45:00', 4, 4),
(3, 'Approved', 'Minor wording fixes verified.',        '2026-10-12 12:00:00', 7, 4);

INSERT INTO MEETING_DECISION (meeting_id, paper_id, decision) VALUES
(1, 1, 'Accepted'),
(3, 4, 'Accepted'),
(3, 7, 'Minor faults'),
(2, 2, 'Pending'),
(5, 10, 'Pending');

INSERT INTO DOCUMENT (doc_id, doc_type, submitted_date, submitted_by, paper_id) VALUES
(1,  'Question Paper',   '2026-10-01', 2,  1),
(2,  'Marking Scheme',   '2026-10-01', 2,  1),
(3,  'Moderator Report', '2026-10-04', 3,  1),
(4,  'Question Paper',   '2026-10-02', 2,  2),
(5,  'Marking Scheme',   '2026-10-02', 2,  2),
(6,  'Moderator Report', '2026-10-03', 3,  2),
(7,  'Question Paper',   '2026-10-18', 9,  3),
(8,  'Question Paper',   '2026-10-02', 5,  4),
(9,  'Marking Scheme',   '2026-10-02', 5,  4),
(10, 'Moderator Report', '2026-10-04', 10, 4),
(11, 'Question Paper',   '2026-10-11', 5,  5),
(12, 'Marking Scheme',   '2026-10-11', 5,  5),
(13, 'Question Paper',   '2026-10-01', 5,  7),
(14, 'Marking Scheme',   '2026-10-01', 5,  7),
(15, 'Moderator Report', '2026-10-03', 10, 7),
(16, 'Question Paper',   '2026-10-19', 11, 8),
(17, 'Marking Scheme',   '2026-10-19', 11, 8),
(18, 'Moderator Report', '2026-10-20', 14, 8),
(19, 'Question Paper',   '2026-10-14', 13, 10),
(20, 'Marking Scheme',   '2026-10-14', 13, 10),
(21, 'Moderator Report', '2026-10-15', 15, 10);

INSERT INTO DOCUMENT_VERSION (version_id, version_no, file_path, uploaded_at, doc_id) VALUES
(1,  1, '/files/c_programming_paper_v1.pdf',   '2026-10-01 14:30:00', 1),
(2,  2, '/files/c_programming_paper_v2.pdf',   '2026-10-07 10:15:00', 1),
(3,  1, '/files/c_programming_scheme_v1.pdf',  '2026-10-01 14:35:00', 2),
(4,  1, '/files/c_programming_modreport_v1.pdf','2026-10-04 17:00:00', 3),
(5,  1, '/files/database_paper_v1.pdf',        '2026-10-02 15:00:00', 4),
(6,  1, '/files/database_scheme_v1.pdf',       '2026-10-02 15:05:00', 5),
(7,  1, '/files/database_modreport_v1.pdf',    '2026-10-03 16:00:00', 6),
(8,  1, '/files/electronics_paper_v1.pdf',     '2026-10-18 10:00:00', 7),
(9,  1, '/files/calculus_paper_v1.pdf',        '2026-10-02 09:00:00', 8),
(10, 1, '/files/calculus_scheme_v1.pdf',       '2026-10-02 09:05:00', 9),
(11, 1, '/files/calculus_modreport_v1.pdf',    '2026-10-04 09:10:00', 10),
(12, 1, '/files/probability_paper_v1.pdf',     '2026-10-11 10:00:00', 11),
(13, 1, '/files/probability_scheme_v1.pdf',    '2026-10-11 10:05:00', 12),
(14, 1, '/files/linear_algebra_paper_v1.pdf',  '2026-10-01 10:00:00', 13),
(15, 1, '/files/linear_algebra_scheme_v1.pdf', '2026-10-01 10:05:00', 14),
(16, 1, '/files/linear_algebra_modreport_v1.pdf','2026-10-03 11:00:00', 15),
(17, 1, '/files/mechanics_paper_v1.pdf',       '2026-10-19 10:00:00', 16),
(18, 1, '/files/mechanics_scheme_v1.pdf',      '2026-10-19 10:05:00', 17),
(19, 1, '/files/mechanics_modreport_v1.pdf',   '2026-10-20 10:00:00', 18),
(20, 1, '/files/cell_biology_paper_v1.pdf',    '2026-10-14 10:00:00', 19),
(21, 1, '/files/cell_biology_scheme_v1.pdf',   '2026-10-14 10:05:00', 20),
(22, 1, '/files/cell_biology_modreport_v1.pdf','2026-10-15 10:00:00', 21);

-- Exam timetable (invigilator = staff user ID). Every sample paper has a slot;
-- HODs can add or change slots from the menu (venue / cohort / invigilator clash checks apply).
INSERT INTO EXAM_TIMETABLE (paper_id, exam_date, start_time, end_time, venue, invigilator_id) VALUES
(1,  '2026-11-20', '09:00:00', '12:00:00', 'Lecture Hall A',  9),
(2,  '2026-12-01', '09:00:00', '12:00:00', 'Lecture Hall A',  7),
(3,  '2026-11-24', '09:00:00', '11:00:00', 'Lecture Hall A',  7),
(4,  '2026-11-25', '13:30:00', '16:30:00', 'Lecture Hall B',  10),
(5,  '2026-12-02', '13:30:00', '16:30:00', 'Lecture Hall B',  5),
(6,  '2026-12-03', '09:00:00', '12:00:00', 'Lecture Hall A',  2),
(7,  '2026-11-27', '09:00:00', '12:00:00', 'Lecture Hall B',  4),
(8,  '2026-12-04', '09:00:00', '12:00:00', 'Lecture Hall B',  14),
(9,  '2026-12-07', '09:00:00', '11:00:00', 'Lecture Hall B',  6),
(10, '2026-11-12', '09:00:00', '12:00:00', 'Biology Hall',    15),
(11, '2026-12-08', '09:00:00', '12:00:00', 'Biology Hall',    12);

INSERT INTO LECTURER_AVAILABILITY (user_id, available_date, is_available) VALUES
(1, '2026-10-30', TRUE),  (3, '2026-10-30', TRUE),  (7, '2026-10-30', FALSE),
(1, '2026-11-02', TRUE),  (3, '2026-11-02', TRUE),  (7, '2026-11-02', TRUE),
(4, '2026-10-30', TRUE),  (5, '2026-10-30', FALSE), (10,'2026-10-30', TRUE),
(2, '2026-10-30', TRUE),  (5, '2026-11-05', FALSE);

INSERT INTO NOTIFICATION (type, message, sent_at, read_at, user_id) VALUES
('Approval', 'Paper "Database Systems Final Paper" is under moderation and awaits your decision.', '2026-10-22 09:35:00', NULL, 1),
('Meeting',  'Scrutiny board meeting on 2026-10-28 at Online (Online).',                         '2026-10-22 10:00:00', NULL, 3),
('Meeting',  'Scrutiny board meeting on 2026-10-28 at Online (Online).',                         '2026-10-22 10:00:00', NULL, 7),
('Reminder', 'Submit the Electronics paper documents before 2026-10-20 - now overdue.',          '2026-10-21 09:00:00', NULL, 9),
('Reminder', 'Submit "Data Structures Final Paper" documents before 2026-10-28.',                '2026-10-24 09:00:00', NULL, 7),
('Approved', 'Your Calculus Final Paper has been approved.',                                      '2026-10-09 12:05:00', '2026-10-09 13:00:00', 5),
('Meeting',  'Scrutiny board meeting on 2026-11-03 at Maths Seminar Room.',                      '2026-10-20 08:00:00', NULL, 4),
('Meeting',  'Scrutiny board meeting on 2026-11-04 at Biology Seminar Room.',                    '2026-10-23 08:30:00', NULL, 12),
('Reminder', 'Submit "Thermodynamics Final Paper" documents before 2026-10-30.',                  '2026-10-24 09:00:00', NULL, 11);
